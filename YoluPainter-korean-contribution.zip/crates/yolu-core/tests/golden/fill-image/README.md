[한국어](README.ko.md) · [日本語](README.md)

# 塗りつぶし投影の C# 正解

0.4.x までの Unity ブリッジの C# Core（Unity ブリッジのタグ `0.4.0` の `Runtime/Core`）の出力を引き継いだ物です。作り直すときは Rust の出力から作ります。すべて人工データです。

異方性を切った道（`FillInput::anisotropic`・`shape_anisotropic` が false）の正解です。入れた道の正解は Rust が撮った [`../fill-image-anisotropic/`](../fill-image-anisotropic/README.md) にあります。

`<mode>-<variant>.rgba` は37×29、straight RGBA8、左下からの行優先です。mode は0 UV、1トライプラナー、2平面、3球面、4円柱、5デカール。variant 0〜7 の入力は Rust の `tests/support/fill_cases.rs` にあります。

`decal-values-<variant>.rgba` はデカール（mode 5）の `ApplyDecalToValue`。同じ variant 0〜7 の設定に、座標だけで決まる人工の値（`tests/support/fill_cases.rs` の `decal_values`）を渡した結果で、形式は上と同じです。

`.rgba` は改行を変換してはいけないバイト列なので、リポジトリの `.gitattributes` で `binary`、このフォルダ全体を `-text` にしています。

`source.txt` は参照元コミットと評価式のSHA-256、`contracts.txt` は拒否設定と予算境界の実行結果です。C# の並列度1と4の全バイト一致を確認してから保存した物です（C# で作り直す道は残していません）。
