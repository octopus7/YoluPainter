//! プロジェクトのアセット（コード上の名前は棚 `shelf`。画面の言葉は「アセット」）の状態と操作。棚は .ylp の resources（yolu-io の `Shelf`）で、画像・ブラシ・マテリアル・
//! スマートマテリアル・スマートマスクを並べる。画面（`panels::assets`）は絞り込み・探す・選ぶだけを直に持ち、棚の中身と文書を変える
//! 操作は `Action::Shelf(ShelfOp)` を通す。
//!
//! - 組み込み: 同梱のスマートマテリアル（`yolu_core::smart_library`）は、棚の項目の後ろに「組み込み」として並ぶ。プロジェクトの棚には入らず
//!   （保存・書き出し・消すの対象外）、置くと文書へ写る。ID は `builtin:` で始まり、素材は項目を見るとき・置くときにコードから組む。
//! - レイヤーからの保存: 選んだレイヤー（グループなら中身ごと）・レイヤーのマスクを core で捕まえ、.ylsmart（`SmartFile::from_core`）にして棚へ入れる。
//!   文書は変えない。棚の変更は文書の Undo の履歴に入らず、未保存にはなる（Unity 版と同じ）。塗りつぶしレイヤーは、マテリアル
//!   （`Document::capture_material`。中身は .ylsmart と同じ形）として個人のライブラリへも書ける（`library::ops`）。
//! - 置く: 棚の .ylsmart（マテリアルも同じ形）を core の素材へ戻し、`place_smart_material`（レイヤーの組。1 回の Undo）・`apply_smart_mask`（マスクの入れ替え。
//!   1 回の Undo）で今の文書へ。置けないときは何も変えず、理由を短く出す（画像入り・Generator の再固定・core が持てない中身・
//!   チャンネルの不一致・予算）。
//! - 画面のスレッドを止める時間: 棚へ足す・消す・読み込むは、yolu-io が棚全体を検証し直すので棚の大きさに比例する。大きな素材
//!   （画素 8 MiB 以上）か大きな棚（素材と棚の使用量の合計が 8 MiB 以上）への「レイヤーを保存」は、変換・圧縮・サムネイルに加えて
//!   棚の写しへの追加も別のスレッドで済ませ、画面のスレッドは足した後の棚に差し替えるだけにする（その間は消す・読み込むを断る）。
//!   消す・読み込むは画面のスレッドで行い、棚が 240〜420 MiB だと、消すは 1.4〜2.8 秒、読み込みは 2〜4 秒止まる。サムネイルのための
//!   展開は別のスレッドで行うので画面を止めない（1 項目 0.1 秒前後。画素 64 MiB の素材で 0.5 秒）。測定は tests/gui_shell/shelf.rs の `measure_`
//!   （最適化 1 のビルドの値。本番のビルドでは短くなる）。
//! - 棚を .ylp に書くのは「変えたとき」だけ（`write_into`）。変えていなければ、開いたファイルの resources をバイト列のまま残す。
//! - サムネイルと一覧の説明は、棚の項目が見えたときに別のスレッドで 1 度だけ作って覚える（`Inspected`。`request_inspections` が
//!   見えている項目だけ頼み、できた分を `poll_inspections` が 1 フレームに数個ずつ受け取る。スクロールで見えなくなった項目の仕事は
//!   始めずに捨てる）。同じ中身の絵は、利用者のキャッシュのフォルダに中身の札で覚える（`library::cache`）。画素は文書の合成の参照の式で
//!   64 点に標本化する（保存の正本には使わない）。
//! - 個人のライブラリ（`library`）のファイルを「プロジェクトで使う」は、別のスレッドで読んで検証し、写しを棚の写しへ足す
//!   （`spawn_import`。出どころは `library`。保存と同じく 1 つずつで、やめられる）。ライブラリへ入れる・置く・消すは `library::ops`。

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;

use egui::{ColorImage, TextureHandle, TextureOptions};
use yolu_core::smart::{SmartKind, SmartMaterial, SmartPlacement};
use yolu_core::smart_library;
use yolu_io::shelf::{ResourceKind, Shelf, MAX_RESOURCES};
use yolu_io::smart::{SmartFile, REFUSAL_GENERATORS, REFUSAL_IMAGES};
use yolu_io::{NativeValue, Project, Resource};

use crate::engine::{Channel, CoreError, Document, LayerId};
use crate::jobs::CloseJob;
use crate::jobs::JobSpec;
use crate::lang::{Count, Lang};
use crate::library::cache::{Cache, Cached};
use crate::library::service::{Cancel, Service, Work};
use crate::notice::{Kind as NoticeKind, Source};
use crate::state::{ui_store, AppState, DialogRequest, UiSlot, Waker};

/// 棚の素材のメモリの予算（Unity 版の既定は RAM の 1/16 を 256〜4096 MiB に収めた値。ここでは固定）。
pub const SHELF_BUDGET: u64 = 512 * 1024 * 1024;
/// 棚に入れる .ylsmart の大きさの上限（読み込みの前に長さで断る）。
pub const IMPORT_LIMIT: u64 = 256 * 1024 * 1024;
/// サムネイルの 1 辺（点）。
pub const THUMB: u32 = 64;
/// 素材のサムネイルのために展開してよい画素の量（バイト。超える素材は種類のアイコンで見せるが、置くことはできる）。
pub const PREVIEW_BUDGET: u64 = 128 * 1024 * 1024;
/// 画像のサムネイルを作る画素数の上限（これを超える画像は種類のアイコンで見せる）。
pub const IMAGE_THUMB_PIXELS: u64 = 4096 * 4096;

/// 同梱の素材を言語に合わせて組む（`builtin:` 付きの ID。無い・組めないときは None）。
fn build_builtin_material(id: &str, lang: Lang) -> Option<SmartMaterial> {
    let entry = smart_library::entries()
        .iter()
        .find(|e| format!("{BUILTIN_PREFIX}{}", e.id) == id)?;
    let japanese = lang == Lang::Ja;
    entry.build(entry.name(japanese), japanese).ok()
}

/// 同梱の素材の項目の ID の前置き（プロジェクトの棚の ID は UUID なので重ならない）。
pub const BUILTIN_PREFIX: &str = "builtin:";

/// 同梱の素材の項目か。
pub fn is_builtin(id: &str) -> bool {
    id.starts_with(BUILTIN_PREFIX)
}

/// 棚の素材の種類。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum ItemKind {
    Image,
    Brush,
    Material,
    SmartMaterial,
    SmartMask,
}

impl ItemKind {
    pub const ALL: [ItemKind; 5] = [
        ItemKind::Image,
        ItemKind::Brush,
        ItemKind::Material,
        ItemKind::SmartMaterial,
        ItemKind::SmartMask,
    ];

    /// 索引の種類の文字列から。
    pub fn of(kind: &str) -> Option<ItemKind> {
        Some(match kind {
            "image" => ItemKind::Image,
            "brush" => ItemKind::Brush,
            "material" => ItemKind::Material,
            "smartMaterial" => ItemKind::SmartMaterial,
            "smartMask" => ItemKind::SmartMask,
            _ => return None,
        })
    }

    pub fn icon(self) -> &'static str {
        match self {
            ItemKind::Image => "texture",
            ItemKind::Brush => "paint_brush",
            ItemKind::Material => "view_in_ar",
            ItemKind::SmartMaterial => "layers",
            ItemKind::SmartMask => "vignette",
        }
    }

    pub fn name(self, lang: Lang) -> &'static str {
        match self {
            ItemKind::Image => lang.t("shelf-images"),
            ItemKind::Brush => lang.t("shelf-brushes"),
            ItemKind::Material => lang.t("shelf-materials"),
            ItemKind::SmartMaterial => lang.t("shelf-smart-materials"),
            ItemKind::SmartMask => lang.t("shelf-smart-masks"),
        }
    }

    /// 1 つの名前（フッター・ツールチップ）。
    pub fn singular(self, lang: Lang) -> &'static str {
        match self {
            ItemKind::Image => lang.t("shelf-image"),
            ItemKind::Brush => lang.t("shelf-brush"),
            ItemKind::Material => lang.t("shelf-material"),
            ItemKind::SmartMaterial => lang.t("shelf-smart-material"),
            ItemKind::SmartMask => lang.t("shelf-smart-mask"),
        }
    }

    pub fn is_smart(self) -> bool {
        matches!(self, ItemKind::SmartMaterial | ItemKind::SmartMask)
    }

    /// 中身が .ylsmart の形の種類か（スマートマテリアル・スマートマスクと、塗りつぶしレイヤーを持つマテリアル）。見る・置くは同じ道を通る。
    pub fn is_smart_file(self) -> bool {
        self.is_smart() || self == ItemKind::Material
    }

    fn resource_kind(self) -> Option<ResourceKind> {
        match self {
            ItemKind::SmartMaterial => Some(ResourceKind::SmartMaterial),
            ItemKind::SmartMask => Some(ResourceKind::SmartMask),
            _ => None,
        }
    }
}

/// 置けない理由（項目を見たときにわかる分。チャンネルの不一致や予算は置くときに core が断る）。
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Block {
    /// ブラシは、ここではまだ置けない（画像は 1 枚のペイントレイヤー、マテリアルは塗りつぶしレイヤーとして置ける）。
    Kind(ItemKind),
    /// 画像を同梱した素材（編集用に開けない）。
    Images,
    /// Generator の再固定を持つ素材。
    Generators,
    /// core が持てない中身（フィルター・Generator・Anchor など）を含む素材。棚には入り、書き出せば原本のまま Unity 版が使える。
    /// 理由は両方の言語で持つ。
    Unsupported(Unreadable),
    /// 読めなかった（壊れている・形式が合わない）。理由は両方の言語で持つ（項目の見方は言語に依らず 1 度だけ覚える）。
    Unreadable(Unreadable),
}

impl Block {
    /// 画面に出す短い理由。
    pub fn reason(&self, lang: Lang) -> String {
        match self {
            Block::Kind(k) => format!(
                "{}{}",
                k.singular(lang),
                lang.t("shelf-cannot-be-placed-yet")
            ),
            Block::Images => lang.t("shelf-contains-images").into(),
            Block::Generators => lang.t("shelf-has-pinned-generators").into(),
            Block::Unsupported(e) => e.reason(lang).to_owned(),
            // 項目の状態の行にも出すので、句点は付けない（「読めません（理由）」）
            Block::Unreadable(e) => lang
                .with_reason(lang.t("shelf-unreadable"), e.reason(lang))
                .trim_end_matches(['。', '.'])
                .to_owned(),
        }
    }
}

enum Thumb {
    None,
    Pending(Picture),
    /// GPU へ上げた（画素は手放した。テクスチャは画面の側の `ui_store` にある）。
    Ready(UiSlot),
}

/// サムネイルの画素（straight RGBA8。画像の上の行から）。別のスレッドで作り、画面のスレッドで GPU へ上げる。ディスクのキャッシュへも
/// この形で書く（`Color32` は掛け済みなので、そこから戻すと値が少しずれる）。
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Picture {
    pub width: u32,
    pub height: u32,
    pub rgba: Vec<u8>,
}

impl Picture {
    fn into_image(self) -> ColorImage {
        let mut image = ColorImage::from_rgba_unmultiplied(
            [self.width as usize, self.height as usize],
            &self.rgba,
        );
        image.source_size = egui::vec2(self.width as f32, self.height as f32);
        image
    }
}

/// 項目を見て 1 度だけ作る情報（言語に依らない部分）。
pub struct Inspected {
    pub width: u32,
    pub height: u32,
    pub layers: usize,
    pub channels: Vec<Channel>,
    pub block: Option<Block>,
    thumb: Thumb,
    /// サムネイルのために展開してよい量（`preview_budget`）が足りずに、アイコンで見せている。量を上げたときの見直しの印で、
    /// ほかの理由でサムネイルが無い素材（画像が大きい・マスクに画素が無い など）には立てない。
    budget_skipped: bool,
}

impl Inspected {
    /// サムネイルのテクスチャ（作ってあれば。初めて使うときに GPU へ上げる）。
    pub(crate) fn texture(&mut self, ctx: &egui::Context, name: &str) -> Option<TextureHandle> {
        if let Thumb::Pending(picture) = &mut self.thumb {
            let picture = std::mem::replace(
                picture,
                Picture {
                    width: 0,
                    height: 0,
                    rgba: Vec::new(),
                },
            );
            let slot = UiSlot::new();
            let handle = ui_store::load_texture(
                ctx,
                &slot,
                name,
                picture.into_image(),
                TextureOptions::LINEAR,
            );
            self.thumb = Thumb::Ready(slot);
            return Some(handle);
        }
        match &self.thumb {
            Thumb::Ready(slot) => ui_store::texture(ctx, slot),
            _ => None,
        }
    }

    /// サムネイルを付ける（別のスレッドで作った絵）。
    pub(crate) fn with_picture(mut self, picture: Picture) -> Inspected {
        self.thumb = Thumb::Pending(picture);
        self
    }

    /// 絵があるか（作ったか・GPU へ上げたか）。
    pub fn has_thumbnail(&self) -> bool {
        !matches!(self.thumb, Thumb::None)
    }

    /// まだ GPU へ上げていない絵の画素（試験が、作った絵を比べるため。上げたあとは None）。
    pub fn picture(&self) -> Option<&Picture> {
        match &self.thumb {
            Thumb::Pending(picture) => Some(picture),
            _ => None,
        }
    }

    pub(crate) fn bare(block: Option<Block>) -> Inspected {
        Inspected {
            width: 0,
            height: 0,
            layers: 0,
            channels: Vec::new(),
            block,
            thumb: Thumb::None,
            budget_skipped: false,
        }
    }
}

/// 別のスレッドで見た結果（項目の ID と、そのときの中身の札。棚が変わっていたら捨てる）。
struct Inspection {
    id: String,
    content: String,
    info: Inspected,
}

/// 項目を見るのに要るもの（棚から写しを共有して取り出す。別のスレッドへ渡せる）。
struct Input {
    id: String,
    kind: ItemKind,
    content: String,
    bytes: Option<Arc<[u8]>>,
    width: u32,
    height: u32,
    builtin: Option<Lang>,
    preview_budget: u64,
    image_thumb_pixels: u64,
}

impl Input {
    /// 項目を見て情報とサムネイルを作る（重い。画面のスレッドでは試験とごく小さな項目だけ）。`cache` があれば、同じ中身の絵は
    /// そこから読み、作った絵はそこへ覚える。取り消されたら（結果は捨てられるので）早く切り上げる。
    fn run(self, cache: Option<&Cache>, cancel: Option<&Cancel>) -> Inspected {
        let stopped = || cancel.is_some_and(Cancel::is_set);
        if stopped() {
            return Inspected::bare(None);
        }
        let bytes = self.bytes.as_deref();
        match self.kind {
            _ if is_builtin(&self.id) => {
                let Some(material) = self
                    .builtin
                    .and_then(|l| build_builtin_material(&self.id, l))
                else {
                    return Inspected::bare(Some(Block::Unreadable(Unreadable::same("?"))));
                };
                let key = Cache::key(
                    "builtin",
                    &format!("{}:{}", self.id, env!("CARGO_PKG_VERSION")),
                );
                remembered(cache, &key, stopped, || (inspect_builtin(&material), None)).0
            }
            ItemKind::Image => {
                let key = Cache::key("image", &self.content);
                remembered(cache, &key, stopped, || {
                    (
                        inspect_image_sized(
                            self.width,
                            self.height,
                            bytes,
                            self.image_thumb_pixels,
                        ),
                        None,
                    )
                })
                .0
            }
            ItemKind::SmartMaterial | ItemKind::SmartMask | ItemKind::Material => {
                let key = Cache::key("smart", &self.content);
                remembered(cache, &key, stopped, || {
                    inspect_smart_kind(bytes, self.preview_budget)
                })
                .0
            }
            ItemKind::Brush => Inspected::bare(Some(Block::Kind(self.kind))),
        }
    }
}

/// キャッシュにあればそれを、無ければ `make` で作って（置けない理由が無く、サムネイルがあるときだけ）覚える。
pub(crate) fn remembered(
    cache: Option<&Cache>,
    key: &str,
    stopped: impl Fn() -> bool,
    make: impl FnOnce() -> (Inspected, Option<SmartKind>),
) -> (Inspected, Option<SmartKind>) {
    if let Some(found) = cache.and_then(|c| c.get(key)) {
        return from_cached(found);
    }
    let (info, kind) = make();
    if let (Some(cache), false) = (cache, stopped()) {
        if let Some(cached) = to_cached(&info, kind) {
            cache.put(key, &cached);
        }
    }
    (info, kind)
}

/// 覚える説明（`key=value` の行）。サムネイルがあって置けない理由の無い項目だけ覚える。
pub(crate) fn to_cached(info: &Inspected, kind: Option<SmartKind>) -> Option<Cached> {
    let Thumb::Pending(picture) = &info.thumb else {
        return None;
    };
    if info.block.is_some() {
        return None;
    }
    let mut text = format!(
        "w={}\nh={}\nlayers={}\n",
        info.width, info.height, info.layers
    );
    if !info.channels.is_empty() {
        let names: Vec<_> = info.channels.iter().map(|c| channel_name(*c)).collect();
        text += &format!("channels={}\n", names.join(","));
    }
    match kind {
        Some(SmartKind::Mask) => text += "kind=mask\n",
        Some(SmartKind::Material) => text += "kind=material\n",
        None => {}
    }
    Some(Cached {
        info: text,
        width: picture.width,
        height: picture.height,
        rgba: picture.rgba.clone(),
    })
}

/// 覚えていた絵と説明から（読めない説明は、寸法 0 のまま絵だけ）。
pub(crate) fn from_cached(cached: Cached) -> (Inspected, Option<SmartKind>) {
    let mut out = Inspected::bare(None);
    let mut kind = None;
    for line in cached.info.lines() {
        let Some((key, value)) = line.split_once('=') else {
            continue;
        };
        match key {
            "w" => out.width = value.parse().unwrap_or(0),
            "h" => out.height = value.parse().unwrap_or(0),
            "layers" => out.layers = value.parse().unwrap_or(0),
            "channels" => {
                out.channels = value.split(',').filter_map(channel_from_name).collect();
            }
            "kind" => {
                kind = match value {
                    "mask" => Some(SmartKind::Mask),
                    "material" => Some(SmartKind::Material),
                    _ => None,
                }
            }
            _ => {}
        }
    }
    out.thumb = Thumb::Pending(Picture {
        width: cached.width,
        height: cached.height,
        rgba: cached.rgba,
    });
    (out, kind)
}

/// 棚を読めなかった理由。日本語は yolu-io の診断のまま、英語は種類ごとの短い文（診断の本文は日本語なので、英語のウィンドウには出さない）。
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Unreadable {
    ja: String,
    en: String,
}

impl Unreadable {
    pub fn reason(&self, lang: Lang) -> &str {
        lang.pick(&self.ja, &self.en)
    }

    /// yolu-io の失敗の種類から（日本語は診断のまま、英語は短い文）。
    pub fn from_error(e: &yolu_io::Error) -> Unreadable {
        Unreadable {
            ja: Lang::Ja.io_error(e),
            en: Lang::En.io_error(e),
        }
    }

    /// 言語ごとの文（`|l| l.t("キー")` で、.ftl の文を両方の言語で引く）。
    pub fn keyed(text: impl Fn(Lang) -> &'static str) -> Unreadable {
        Unreadable {
            ja: text(Lang::Ja).to_owned(),
            en: text(Lang::En).to_owned(),
        }
    }

    /// 言語ごとの文（呼ぶ側が言語ごとに作った文）。
    pub fn pair(ja: &str, en: &str) -> Unreadable {
        Unreadable {
            ja: ja.to_owned(),
            en: en.to_owned(),
        }
    }

    /// 両方の言語で同じ文。
    pub fn same(text: &str) -> Unreadable {
        Unreadable {
            ja: text.to_owned(),
            en: text.to_owned(),
        }
    }
}

/// 棚の状態。
pub struct ShelfState {
    shelf: Shelf,
    /// 棚を読めなかった理由（あれば棚を変える操作を断る。保存では開いたファイルの resources をそのまま残す）。
    pub unavailable: Option<Unreadable>,
    /// 開いた・保存した後に変えたか（変えていなければ保存で resources に触らない）。
    pub changed: bool,
    /// 種類の絞り込み（None はすべて）。
    pub filter: Option<ItemKind>,
    pub search: String,
    /// 選んでいる素材の ID。
    pub selected: Option<String>,
    pub scroll: f32,
    /// 消す確認の待ち（ファイルのウィンドウと同じく `YoluApp` が確かめる）。
    pub pending_remove: Option<String>,
    /// 書き出す素材（ファイルを選ぶウィンドウの待ち）。
    pub export_id: Option<String>,
    /// 別のスレッドで書き出している保存（1 つだけ。取り消すか、終わると外れる）。
    saving: Option<PendingSave>,
    /// 走っている書き出しのスレッドの数。「やめる」はスレッドを止めない（結果を捨てるだけ）ので、やめた後もスレッドが
    /// 終わるまで次の保存を断る（4096² の書き出しが並列に積み上がらない）。プロジェクトを替えても引き継ぐ。
    running: Arc<AtomicUsize>,
    /// 画素がこの大きさ以上の素材は別のスレッドで書き出す。
    pub async_bytes: u64,
    /// 素材のサムネイルのために展開してよい画素の量（バイト。試験で小さくする）。
    pub preview_budget: u64,
    /// 画像のサムネイルを作る画素数の上限（試験で小さくする）。
    pub image_thumb_pixels: u64,
    /// 読み込む .ylsmart の大きさの上限（バイト。試験で小さくする）。
    pub import_limit: u64,
    /// 書き出しが終わったことを画面に知らせる口（毎フレーム `YoluApp` が渡す）。
    pub waker: Option<Waker>,
    /// 試験用: true の間、別のスレッドの書き出しは結果を渡さずに待つ。
    hold: Arc<AtomicBool>,
    inspected: HashMap<String, Inspected>,
    /// 同梱の素材の項目（今の言語の名前。`use_language` で作り直す）。
    builtin: Vec<Resource>,
    builtin_lang: Option<Lang>,
    /// 同梱の素材を一覧に出すか（既定は出す。プロジェクトの棚だけの並びを調べる試験が false にする）。
    pub show_builtin: bool,
    /// 見えている項目の情報とサムネイルを作る別のスレッドの仕事場（棚を替えると、前の棚の仕事は捨てる）。
    inspector: Service<Inspection>,
}

/// 別のスレッドで書き出している素材。
struct PendingSave {
    name: String,
    kind: ItemKind,
    rx: std::sync::mpsc::Receiver<Result<Staged, yolu_io::Error>>,
    /// やめた・捨てたことをスレッドへ伝える旗（サムネイルを作らず切り上げる。変換と圧縮の途中では止められない）。
    cancel: Arc<AtomicBool>,
    /// 個人のライブラリのファイルを取り込んでいる（レイヤーの保存ではない）。
    from_library: bool,
}

impl Drop for PendingSave {
    fn drop(&mut self) {
        self.cancel.store(true, Ordering::SeqCst);
    }
}

/// 走っている書き出しのスレッドの数え（作った時に増え、落ちた時に減る。パニックでも減る）。
pub(crate) struct Running(Arc<AtomicUsize>);

impl Running {
    pub(crate) fn start(count: &Arc<AtomicUsize>) -> Running {
        count.fetch_add(1, Ordering::SeqCst);
        Running(count.clone())
    }
}

impl Drop for Running {
    fn drop(&mut self) {
        self.0.fetch_sub(1, Ordering::SeqCst);
    }
}

/// 書き出し終えた素材（.ylsmart のバイト列と、一覧に出す情報・サムネイル）。
struct Encoded {
    bytes: Vec<u8>,
    /// 一覧の情報（無ければ最初に見るときに作る）。
    info: Option<Inspected>,
}

/// 素材を棚の写しへ足した結果。`next` が足した後の棚（同じ中身が既にあったときは足す前のまま）。足すときの棚全体の検証は棚の
/// 大きさに比例して長いので、別のスレッドの保存では、そちらで済ませて画面のスレッドは `next` に差し替えるだけにする。
pub(crate) struct Staged {
    next: Shelf,
    id: String,
    added: bool,
    info: Option<Inspected>,
    /// 元の画像が 8 ビットへ丸められた（16 ビットの PNG）。取り込みの知らせに足す。
    rounded: bool,
}

impl Staged {
    /// 元の画像を 8 ビットへ丸めたことを覚える。
    pub(crate) fn rounded(mut self, rounded: bool) -> Staged {
        self.rounded = rounded;
        self
    }
}

/// 棚の写し `shelf` へ、個人のライブラリのファイルの中身（スマート素材・ブラシ・マテリアルの .yl* ファイルそのまま）を足す。出どころは
/// ライブラリ（`rel`・ファイルの `sha256`）。拒否では何も返さない（元の棚は変わらない）。
pub(crate) fn stage_library_file(
    mut shelf: Shelf,
    name: &str,
    kind: ResourceKind,
    bytes: &[u8],
    rel: &str,
    sha256: &str,
) -> Result<Staged, yolu_io::Error> {
    let before = shelf.resources().len();
    let id = shelf.add_file_from_library(&new_resource_id(), name, kind, bytes, rel, sha256)?;
    let added = shelf.resources().len() > before;
    Ok(Staged {
        next: shelf,
        id,
        added,
        info: None,
        rounded: false,
    })
}

/// `stage_library_file` の画像版（画素は文書と同じ向き＝下の行が先の straight RGBA8。`length` は元のファイルの長さ）。
#[allow(clippy::too_many_arguments)]
pub(crate) fn stage_library_image(
    mut shelf: Shelf,
    name: &str,
    rgba: &[u8],
    width: u32,
    height: u32,
    rel: &str,
    sha256: &str,
    length: u64,
) -> Result<Staged, yolu_io::Error> {
    let before = shelf.resources().len();
    let id = shelf.add_image_from_library(
        &new_resource_id(),
        name,
        rgba,
        width,
        height,
        "unspecified",
        rel,
        sha256,
        length,
    )?;
    let added = shelf.resources().len() > before;
    Ok(Staged {
        next: shelf,
        id,
        added,
        info: None,
        rounded: false,
    })
}

/// 棚の写し `shelf` へ素材を足す（拒否では何も返さない。元の棚は変わらない）。
fn stage(
    mut shelf: Shelf,
    name: &str,
    kind: ItemKind,
    done: Encoded,
) -> Result<Staged, yolu_io::Error> {
    let before = shelf.resources().len();
    let id = shelf.add_file_without_origin(
        &new_resource_id(),
        name,
        kind.resource_kind().expect("スマートな種類"),
        &done.bytes,
    )?;
    let added = shelf.resources().len() > before;
    Ok(Staged {
        next: shelf,
        id,
        added,
        info: done.info,
        rounded: false,
    })
}

/// この大きさ（画素のバイト）以上の素材の書き出しは別のスレッドで行う（Unity 版と同じ 8 MiB）。
pub const ASYNC_SAVE_BYTES: u64 = 8 * 1024 * 1024;

/// 項目の情報とサムネイルを作るスレッドの数（描いている間も画面を止めないよう、少なく）。
pub const INSPECT_WORKERS: usize = 1;
/// 1 フレームに画面のスレッドが受け取るできあがりの数。
pub const INSPECTIONS_PER_FRAME: usize = 8;

impl Default for ShelfState {
    fn default() -> Self {
        ShelfState::with_shelf(Shelf::new(SHELF_BUDGET))
    }
}

impl ShelfState {
    pub fn with_shelf(shelf: Shelf) -> ShelfState {
        ShelfState {
            shelf,
            unavailable: None,
            changed: false,
            filter: None,
            search: String::new(),
            selected: None,
            scroll: 0.0,
            pending_remove: None,
            export_id: None,
            saving: None,
            running: Arc::new(AtomicUsize::new(0)),
            async_bytes: ASYNC_SAVE_BYTES,
            preview_budget: PREVIEW_BUDGET,
            image_thumb_pixels: IMAGE_THUMB_PIXELS,
            import_limit: IMPORT_LIMIT,
            waker: None,
            hold: Default::default(),
            inspected: HashMap::new(),
            builtin: Vec::new(),
            builtin_lang: None,
            show_builtin: true,
            inspector: Service::new(INSPECT_WORKERS),
        }
    }

    /// 同梱の素材の項目の名前を言語に合わせる（変わったときだけ作り直す。サムネイルは言語に依らないので捨てない）。
    pub fn use_language(&mut self, lang: Lang) {
        if self.builtin_lang == Some(lang) {
            return;
        }
        let japanese = lang == Lang::Ja;
        self.builtin = smart_library::entries()
            .iter()
            .map(|e| {
                let id = format!("{BUILTIN_PREFIX}{}", e.id);
                let name = e.name(japanese).to_owned();
                Resource {
                    // 棚のファイルの索引の項目ではない（読む所は `metadata` の寸法だけで、無ければ 0）
                    metadata: Default::default(),
                    id,
                    kind: "smartMaterial".into(),
                    name,
                    content: String::new(),
                    entry: String::new(),
                }
            })
            .collect();
        self.builtin_lang = Some(lang);
    }

    /// 同梱の素材を今の言語で組む（棚に無い ID・組めないときは None）。
    pub fn build_builtin(&self, id: &str, lang: Lang) -> Option<SmartMaterial> {
        build_builtin_material(id, lang)
    }

    /// 試験用: true の間、別のスレッドの書き出しは結果を渡さずに待つ（途中の画面・取り消しを確かめるため）。
    pub fn hold_saves(&self, hold: bool) {
        self.hold.store(hold, Ordering::SeqCst);
    }

    /// 別のスレッドで素材を書き出している（`Some(true)` は個人のライブラリのファイルの取り込み、`Some(false)` はレイヤーの保存。無ければ None）。
    pub fn pending_save(&self) -> Option<bool> {
        self.saving.as_ref().map(|p| p.from_library)
    }

    /// 走っている書き出しのスレッドの数（やめた保存のスレッドも、終わるまで数える）。
    pub fn saves_running(&self) -> usize {
        self.running.load(Ordering::SeqCst)
    }

    /// 走っている書き出しのスレッドがすべて終わるまで待つ（試験用）。
    pub fn wait_idle(&self) {
        while self.saves_running() > 0 {
            std::thread::sleep(std::time::Duration::from_millis(1));
        }
    }

    /// プロジェクトを替えるとき、走っているスレッドの数えを引き継ぐ（新しい棚でも前のスレッドが終わるまで次の保存は始めない）。
    /// 試験用の「待つ」旗も同じものにする（新しい棚から前のスレッドを放せる）。
    pub fn inherit_running_from(mut self, old: &ShelfState) -> ShelfState {
        self.running = old.running.clone();
        self.hold = old.hold.clone();
        self
    }

    /// 別のスレッドで保存している素材の名前（保存中でなければ None）。
    pub fn saving_name(&self) -> Option<&str> {
        self.saving.as_ref().map(|p| p.name.as_str())
    }

    /// 別のスレッドの仕事の呼び名（レイヤーの保存か、ライブラリのファイルの取り込みか）。
    pub fn saving_label(&self, lang: Lang) -> &'static str {
        if self.saving.as_ref().is_some_and(|p| p.from_library) {
            lang.t("shelf-importing")
        } else {
            lang.t("shelf-saving")
        }
    }

    /// 個人のライブラリのファイルを別のスレッドで読んで検証し、棚の写しへ足す（できたら `shelf_poll` が棚へ入れる）。`job` は取り消しの
    /// 旗と棚の写しをもらい、足した後の棚を返す。次の保存・取り込みは、終わるまで断る（やめても、スレッドが終わるまで）。
    pub(crate) fn spawn_import(
        &mut self,
        name: String,
        kind: ItemKind,
        job: impl FnOnce(&AtomicBool, Shelf) -> Result<Staged, yolu_io::Error> + Send + 'static,
    ) {
        let (tx, rx) = std::sync::mpsc::channel();
        let repaint = self.waker.clone();
        let hold = self.hold.clone();
        let cancel = Arc::new(AtomicBool::new(false));
        let running = Running::start(&self.running);
        let thread_cancel = cancel.clone();
        let snapshot = self.shelf.clone();
        std::thread::spawn(move || {
            let done = job(&thread_cancel, snapshot).and_then(|staged| {
                if thread_cancel.load(Ordering::SeqCst) {
                    Err(yolu_io::Error::Core(CoreError::Cancelled))
                } else {
                    Ok(staged)
                }
            });
            while hold.load(Ordering::SeqCst) {
                std::thread::sleep(std::time::Duration::from_millis(1));
            }
            drop(running);
            let _ = tx.send(done);
            if let Some(waker) = repaint {
                waker.wake();
            }
        });
        self.saving = Some(PendingSave {
            name,
            kind,
            rx,
            cancel,
            from_library: true,
        });
    }

    /// 次の保存を始められない理由（書き出しが走っている間。やめた保存のスレッドが終わるまでも）。
    pub fn busy_reason(&self, lang: Lang) -> Option<&'static str> {
        if self.saving.as_ref().is_some_and(|p| p.from_library) {
            Some(lang.t("shelf-already-importing"))
        } else if self.saving.is_some() {
            Some(lang.t("shelf-already-saving"))
        } else if self.saves_running() > 0 {
            Some(lang.t("shelf-finishing-the-cancelled-save"))
        } else {
            None
        }
    }

    /// 開いた .ylp の棚。読めなければ空の棚にして理由を覚える（棚を変える操作を断り、保存では resources に触らない）。
    pub fn from_project(project: &Project) -> ShelfState {
        ShelfState::from_read(project.shelf(SHELF_BUDGET))
    }

    /// 棚を読んだ結果から。読めなければ空の棚にして理由を覚える。
    pub fn from_read(read: Result<Shelf, yolu_io::Error>) -> ShelfState {
        match read {
            Ok(shelf) => ShelfState::with_shelf(shelf),
            Err(e) => ShelfState {
                unavailable: Some(Unreadable::from_error(&e)),
                ..ShelfState::default()
            },
        }
    }

    /// 読めなかった棚（空。棚を変える操作は断る）。理由は両方の言語で同じ文（試験用。実際は `from_read` が種類から作る）。
    pub fn unreadable(reason: &str) -> ShelfState {
        ShelfState {
            unavailable: Some(Unreadable::same(reason)),
            ..ShelfState::default()
        }
    }

    pub fn shelf(&self) -> &Shelf {
        &self.shelf
    }

    /// 画像（左下原点・straight RGBA8）を棚へ足す（出どころの記録なし。外のパスを .ylp に書かない）。同じ中身が既にあれば、その ID
    /// （棚は変わらない）。足したら棚は「変えた」になる。棚を読めなかった・予算や個数の上限・壊れた画素は理由を返す（棚は変わらない）。
    pub fn add_image(
        &mut self,
        lang: Lang,
        name: &str,
        rgba: &[u8],
        width: u32,
        height: u32,
    ) -> Result<String, String> {
        if let Some(reason) = &self.unavailable {
            return Err(reason.reason(lang).to_owned());
        }
        let before = self.shelf.resources().len();
        let id = self
            .shelf
            .add_image_without_origin(&new_resource_id(), name, rgba, width, height, "srgb")
            .map_err(|e| crate::lang::shelf_io_error(lang, &e))?;
        if self.shelf.resources().len() > before {
            self.changed = true;
        }
        Ok(id)
    }

    /// 棚の画像の色空間（"srgb"・"linear"・"unspecified"）を替える。色空間は索引にだけあり、文書の履歴に入らない（Unity 版と同じ）。
    /// 棚を読めなかった・無い画像・同じ値は false か理由。替えたら棚は「変えた」になる。
    pub fn set_image_color_space(
        &mut self,
        lang: Lang,
        id: &str,
        space: &str,
    ) -> Result<bool, String> {
        if let Some(reason) = &self.unavailable {
            return Err(reason.reason(lang).to_owned());
        }
        let changed = self
            .shelf
            .set_image_color_space(id, space)
            .map_err(|e| crate::lang::shelf_io_error(lang, &e))?;
        if changed {
            self.changed = true;
        }
        Ok(changed)
    }

    pub fn resources(&self) -> &[Resource] {
        self.shelf.resources()
    }

    pub fn get(&self, id: &str) -> Option<&Resource> {
        self.shelf
            .resources()
            .iter()
            .chain(self.builtin_items())
            .find(|r| r.id == id)
    }

    /// 一覧に出す同梱の素材の項目。
    fn builtin_items(&self) -> &[Resource] {
        if self.show_builtin {
            &self.builtin
        } else {
            &[]
        }
    }

    pub fn selected_resource(&self) -> Option<&Resource> {
        self.selected.as_deref().and_then(|id| self.get(id))
    }

    /// 絞り込み・名前の検索（大文字小文字を区別しない）に合う素材（棚の並びのまま）。
    pub fn visible(&self) -> Vec<&Resource> {
        let needle = self.search.trim().to_lowercase();
        self.shelf
            .resources()
            .iter()
            .chain(self.builtin_items())
            .filter(|r| self.filter.is_none_or(|f| ItemKind::of(&r.kind) == Some(f)))
            .filter(|r| needle.is_empty() || r.name.to_lowercase().contains(&needle))
            .collect()
    }

    pub fn info(&self, id: &str) -> Option<&Inspected> {
        self.inspected.get(id)
    }

    /// 素材のサムネイルのために展開してよい量を替える（設定の GPU のメモリ）。上げたときは、量が足りずにアイコンのままの素材を見直す
    /// （次の `inspect` が、新しい量で作る）。下げても、作ってあるサムネイルは残す。
    pub fn set_preview_budget(&mut self, bytes: u64) {
        if bytes > self.preview_budget {
            self.inspected.retain(|_, info| !info.budget_skipped);
        }
        self.preview_budget = bytes;
    }

    /// 項目を見るのに要るものを集める（無い項目・知らない種類は None）。
    fn input_of(&self, id: &str) -> Option<Input> {
        let r = self.get(id)?;
        let kind = ItemKind::of(&r.kind)?;
        Some(Input {
            id: id.to_owned(),
            kind,
            content: r.content.clone(),
            bytes: if is_builtin(id) || kind == ItemKind::Brush {
                None
            } else {
                self.shelf.content_arc(id)
            },
            width: r.metadata["width"].as_u64().unwrap_or(0) as u32,
            height: r.metadata["height"].as_u64().unwrap_or(0) as u32,
            builtin: self.builtin_lang,
            preview_budget: self.preview_budget,
            image_thumb_pixels: self.image_thumb_pixels,
        })
    }

    /// 項目の情報とサムネイルを（まだなら）この場で作る。試験用（画面のスレッドで画素を展開するので、画面は使わない。
    /// 画面は `request_inspections` で別のスレッドへ頼む）。
    pub fn inspect(&mut self, id: &str) {
        if self.inspected.contains_key(id) {
            return;
        }
        let Some(input) = self.input_of(id) else {
            return;
        };
        let info = input.run(None, None);
        self.inspected.insert(id.to_owned(), info);
    }

    /// 新しいフレームの始まり（見えている項目を `request_inspections` で頼む前に 1 度）。
    pub fn begin_inspection_frame(&self, waker: Waker) {
        self.inspector.set_waker(waker);
        self.inspector.begin_frame();
    }

    /// できたときに画面を描き直させる口（棚のタブを開いていなくても、塗りつぶしの画像の箱などが `request_inspections` で頼める）。
    pub fn attach_repaint(&self, waker: Waker) {
        self.inspector.set_waker(waker);
    }

    /// 見えている項目のうち、まだ見ていないものの情報とサムネイルを、別のスレッドへ頼む（頼み済みは見に来た印だけ）。
    /// 置けるか・読めるかの判定が要らない種類（ブラシ）はその場で決める。`cache` はディスクのキャッシュ。
    pub fn request_inspections(&mut self, ids: &[String], cache: Option<&Arc<Cache>>) {
        for id in ids {
            if self.inspected.contains_key(id) {
                continue;
            }
            let Some(input) = self.input_of(id) else {
                continue;
            };
            if input.kind == ItemKind::Brush {
                let info = input.run(None, None);
                self.inspected.insert(id.clone(), info);
                continue;
            }
            let cache = cache.cloned();
            self.inspector.request(id, move || -> Work<Inspection> {
                Box::new(move |cancel| Inspection {
                    id: input.id.clone(),
                    content: input.content.clone(),
                    info: input.run(cache.as_deref(), Some(cancel)),
                })
            });
        }
    }

    /// できあがった項目を `limit` 個まで受け取って覚える（棚から消えた・中身が替わった項目の結果は捨てる）。受け取った数。
    pub fn poll_inspections(&mut self, limit: usize) -> usize {
        let done = self.inspector.poll(limit);
        let count = done.len();
        for (key, result) in done {
            match result {
                Some(Inspection { id, content, info }) => {
                    if self.get(&id).is_some_and(|r| r.content == content) {
                        self.inspected.insert(id, info);
                    }
                }
                // 仕事が途中で落ちた項目は、読めない印で覚える（頼み直し続けない）
                None => {
                    if self.get(&key).is_some() {
                        self.inspected.insert(
                            key,
                            Inspected::bare(Some(Block::Unreadable(Unreadable::same("?")))),
                        );
                    }
                }
            }
        }
        count
    }

    /// 頼んであって、まだ受け取っていない項目があるか（あれば、画面は続けて描き直す）。
    pub fn inspections_pending(&self) -> bool {
        self.inspector.pending() > 0
    }

    /// 試験用: 頼んだ仕事がすべて終わるまで待って、できた分を受け取る。
    pub fn wait_inspections(&mut self) {
        self.inspector.wait_done();
        while self.poll_inspections(usize::MAX) > 0 {}
    }

    /// 試験用: true の間、別のスレッドは新しい項目を見始めない。
    pub fn hold_inspections(&self, hold: bool) {
        self.inspector.hold(hold);
    }

    /// 見える項目のうちまだ見ていないものを `limit` 個まで、この場で見る（試験用。画面は `request_inspections`）。まだ残っていれば true。
    pub fn inspect_pending(&mut self, limit: usize) -> bool {
        let todo: Vec<String> = self
            .visible()
            .iter()
            .filter(|r| !self.inspected.contains_key(&r.id))
            .map(|r| r.id.clone())
            .collect();
        for id in todo.iter().take(limit) {
            self.inspect(id);
        }
        todo.len() > limit
    }

    /// サムネイルのテクスチャ（作ってあれば。初めて使うときに GPU へ上げる）。
    pub fn texture(&mut self, ctx: &egui::Context, id: &str) -> Option<TextureHandle> {
        let info = self.inspected.get_mut(id)?;
        info.texture(ctx, &format!("shelf:{id}"))
    }

    /// 一覧に出す説明（レイヤーの数・大きさ・チャンネル）。
    pub fn detail(&self, lang: Lang, r: &Resource) -> String {
        let Some(kind) = ItemKind::of(&r.kind) else {
            return String::new();
        };
        let image_size = (
            r.metadata["width"].as_u64().unwrap_or(0) as u32,
            r.metadata["height"].as_u64().unwrap_or(0) as u32,
        );
        describe(lang, kind, self.info(&r.id), image_size, is_builtin(&r.id))
    }

    /// 棚の素材の置けない理由（まだ見ていなければ None）。
    pub fn block_of(&self, id: &str) -> Option<&Block> {
        self.info(id)?.block.as_ref()
    }

    /// 一覧に置けないしるし（警告の印）を出す素材か。素材の中身で置けないものだけで、種類で置けないもの（ブラシ）は
    /// 印を付けず、名前の帯に理由を出す。
    pub fn warns(&self, id: &str) -> bool {
        self.block_of(id)
            .is_some_and(|b| !matches!(b, Block::Kind(_)))
    }

    /// 項目が文書のレイヤーから使われているか（読むだけのセットの塗りつぶし画像など）。使われている画像は消さない。
    fn used_by(&self, project: Option<&Project>, id: &str) -> bool {
        let Some(project) = project else { return false };
        project.sets().iter().any(|s| {
            // 正本の骨組み（ID の項目）。読めない正本は、使っている物を消さないよう、使っているとみなす
            s.document.skeleton().map_or(true, |d| {
                d.fields()
                    .iter()
                    .any(|f| matches!(&f.value, NativeValue::Guid(g) if guid_text(g) == id))
            })
        })
    }

    /// 変えていれば、棚を差し替えたプロジェクトを返す（変えていなければそのまま）。書き手は保存したアプリ。
    pub fn write_into(&self, project: Project, lang: Lang) -> Result<Project, String> {
        if !self.changed {
            return Ok(project);
        }
        project
            .with_shelf(&self.shelf, crate::project::writer())
            .map_err(|e| {
                lang.with_reason(
                    lang.t("shelf-cannot-write-the-project-s"),
                    lang.io_error(&e),
                )
            })
    }
}

/// 項目の説明（画像は大きさ、スマートマテリアルはレイヤーの数・大きさ・チャンネル、スマートマスクは大きさ。まだ見ていない項目は空）。
/// 同梱の素材は大きさに依らない（値と Generator だけ）ので、大きさを出さない。
pub(crate) fn describe(
    lang: Lang,
    kind: ItemKind,
    info: Option<&Inspected>,
    image_size: (u32, u32),
    builtin: bool,
) -> String {
    let size = |w: u32, h: u32| format!("{w} × {h}");
    match (kind, info) {
        (ItemKind::Image, _) => size(image_size.0, image_size.1),
        (ItemKind::SmartMaterial, Some(i)) if i.width > 0 => {
            let mut text = lang.f("shelf-layer-count", &[("n", &Count(i.layers))]);
            if !builtin {
                text += &format!(" · {}", size(i.width, i.height));
            }
            if !i.channels.is_empty() {
                let names: Vec<_> = i.channels.iter().map(|c| channel_label(lang, *c)).collect();
                text += &format!(" · {}", names.join(", "));
            }
            text
        }
        (ItemKind::SmartMask, Some(i)) if i.width > 0 => size(i.width, i.height),
        _ => String::new(),
    }
}

/// .NET の GUID の並びから、.ylp の ID の文字列へ（yolu-io の `guid` と同じ）。
fn guid_text(b: &[u8; 16]) -> String {
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[3],
        b[2],
        b[1],
        b[0],
        b[5],
        b[4],
        b[7],
        b[6],
        b[8],
        b[9],
        b[10],
        b[11],
        b[12],
        b[13],
        b[14],
        b[15]
    )
}

fn channel_from_name(name: &str) -> Option<Channel> {
    Some(match name {
        "Color" => Channel::Color,
        "Roughness" => Channel::Roughness,
        "Metallic" => Channel::Metallic,
        "Height" => Channel::Height,
        "Normal" => Channel::Normal,
        "Emission" => Channel::Emission,
        _ => return None,
    })
}

/// `channel_from_name` の逆（索引・キャッシュに書く名前）。標準のチャンネル以外は空。
fn channel_name(c: Channel) -> &'static str {
    match c {
        Channel::Color => "Color",
        Channel::Roughness => "Roughness",
        Channel::Metallic => "Metallic",
        Channel::Height => "Height",
        Channel::Normal => "Normal",
        Channel::Emission => "Emission",
        _ => "",
    }
}

fn channel_label(lang: Lang, c: Channel) -> &'static str {
    match c {
        Channel::Color => lang.t("shelf-color"),
        Channel::Roughness => lang.t("shelf-roughness"),
        Channel::Metallic => lang.t("shelf-metallic"),
        Channel::Height => lang.t("shelf-height"),
        Channel::Normal => lang.t("shelf-normal"),
        Channel::Emission => lang.t("shelf-emission"),
        _ => "",
    }
}

// ───────── 項目を見る（サムネイル・置けない理由） ─────────

/// 画像の情報とサムネイル（寸法は索引にある値。画素数が `thumb_pixels` を超える画像・読めない画像は、寸法だけでサムネイル無し）。
pub(crate) fn inspect_image_sized(
    width: u32,
    height: u32,
    bytes: Option<&[u8]>,
    thumb_pixels: u64,
) -> Inspected {
    let mut info = Inspected::bare(None);
    info.width = width;
    info.height = height;
    if width as u64 * height as u64 > thumb_pixels {
        return info;
    }
    let Some(bytes) = bytes else { return info };
    if let Ok(img) = image::load_from_memory_with_format(bytes, image::ImageFormat::Png) {
        info.thumb = Thumb::Pending(image_picture(&img.to_rgba8()));
    }
    info
}

/// 画像（straight RGBA8）のサムネイル。長い辺が `THUMB` に収まる大きさで、小さい画像は拡大して見せる（ぼかさず、画素のまま）。
pub(crate) fn image_picture(img: &image::RgbaImage) -> Picture {
    let (w, h) = fit_size(img.width(), img.height());
    let filter = if w >= img.width() {
        image::imageops::FilterType::Nearest
    } else {
        image::imageops::FilterType::Triangle
    };
    let small = image::imageops::resize(img, w, h, filter);
    Picture {
        width: w,
        height: h,
        rgba: small.into_raw(),
    }
}

/// 長い辺が `THUMB` に収まる大きさ（細長くても 1 以上）。
fn fit_size(w: u32, h: u32) -> (u32, u32) {
    let k = THUMB as f32 / w.max(h).max(1) as f32;
    (
        ((w as f32 * k).round() as u32).clamp(1, THUMB),
        ((h as f32 * k).round() as u32).clamp(1, THUMB),
    )
}

/// スマート素材の情報とサムネイル（ファイルの中の種類。スマートマテリアルかスマートマスクか。読めなければ None）。
pub(crate) fn inspect_smart_kind(
    bytes: Option<&[u8]>,
    preview_budget: u64,
) -> (Inspected, Option<SmartKind>) {
    let Some(bytes) = bytes else {
        return (
            Inspected::bare(Some(Block::Unreadable(Unreadable::same("?")))),
            None,
        );
    };
    let file = match SmartFile::read(bytes) {
        Ok(f) => f,
        Err(e) => return (Inspected::bare(Some(block_from(&e))), None),
    };
    let info = file.info();
    let mut out = Inspected::bare(None);
    out.width = info["width"].as_u64().unwrap_or(0) as u32;
    out.height = info["height"].as_u64().unwrap_or(0) as u32;
    out.layers = info["layers"].as_u64().unwrap_or(0) as usize;
    if let Some(list) = info["channels"].as_array() {
        out.channels = list
            .iter()
            .filter_map(|v| v.as_str().and_then(channel_from_name))
            .collect();
    }
    // サムネイルのために展開する量には上限がある（超える素材はアイコンで見せる。置くときには上限なしで展開する）
    match file.to_core_within(preview_budget) {
        Ok(material) => {
            out.thumb = smart_picture(&material)
                .map(Thumb::Pending)
                .unwrap_or(Thumb::None)
        }
        // 展開の予算を超えただけの素材は、アイコンで見せて置ける（置くときの展開に上限は無い）。io が予算の種類で返す
        Err(yolu_io::Error::Budget(_) | yolu_io::Error::Core(CoreError::SourceBudgetExceeded)) => {
            out.budget_skipped = true
        }
        Err(e) => out.block = Some(smart_block(&file, &e)),
    }
    (out, Some(file.kind()))
}

/// 捕まえた素材を .ylsmart のバイト列にして、一覧の情報（サムネイル）を作る（別のスレッドでも呼ぶ）。`cancel` が立っていれば
/// （やめた・捨てた）、結果は使われないのでサムネイルを作らず切り上げる。変換と圧縮の途中では止められない。
fn encode_material(
    material: &SmartMaterial,
    cancel: Option<&AtomicBool>,
) -> Result<Encoded, yolu_io::Error> {
    let cancelled = || cancel.is_some_and(|c| c.load(Ordering::SeqCst));
    if cancelled() {
        return Err(yolu_io::Error::Core(CoreError::Cancelled));
    }
    let file = SmartFile::from_core(material, &crate::project::writer())?;
    Ok(Encoded {
        bytes: file.file_bytes().to_vec(),
        info: (!cancelled()).then(|| inspect_material(material)),
    })
}

/// 同梱の素材の情報。サムネイルは文書全体を 1 回合成して標本化する（画素を持たない小さな文書なので軽い。
/// `smart_thumbnail` は 1 点ずつ合成するので、Generator の入った文書では遅い）。
fn inspect_builtin(material: &SmartMaterial) -> Inspected {
    let mut out = Inspected::bare(None);
    out.width = material.width();
    out.height = material.height();
    out.layers = material.layers().len();
    out.channels = material.channels();
    out.thumb = builtin_picture(material)
        .map(Thumb::Pending)
        .unwrap_or(Thumb::None);
    out
}

fn builtin_picture(material: &SmartMaterial) -> Option<Picture> {
    let (w, h) = (material.width(), material.height());
    let doc = material.fragment_document().ok()?;
    let all = doc
        .composite_channel(Channel::Color, yolu_core::Rect::new(0, 0, w, h))
        .ok()?;
    let (tw, th) = fit_size(w, h);
    let mut rgba = Vec::with_capacity((tw * th) as usize * 4);
    for ty in 0..th {
        for tx in 0..tw {
            let x = (((tx as f32 + 0.5) * w as f32 / tw as f32) as u32).min(w - 1);
            // 画像は上の行から、文書は下の行から
            let y = h - 1 - (((ty as f32 + 0.5) * h as f32 / th as f32) as u32).min(h - 1);
            rgba.extend_from_slice(&all[(y as usize * w as usize + x as usize) * 4..][..4]);
        }
    }
    Some(Picture {
        width: tw,
        height: th,
        rgba,
    })
}

/// 保存したばかりの素材の情報（読み直さない）。
fn inspect_material(material: &SmartMaterial) -> Inspected {
    let mut out = Inspected::bare(None);
    out.width = material.width();
    out.height = material.height();
    out.layers = material.layers().len();
    out.channels = material.channels();
    out.thumb = smart_picture(material)
        .map(Thumb::Pending)
        .unwrap_or(Thumb::None);
    out
}

/// yolu-io が編集用に開けない素材を断る文言から、置けない理由へ。
fn block_from(e: &yolu_io::Error) -> Block {
    let message = e.to_string();
    if message.contains(REFUSAL_IMAGES) {
        Block::Images
    } else if message.contains(REFUSAL_GENERATORS) {
        Block::Generators
    } else {
        Block::Unreadable(Unreadable::from_error(e))
    }
}

/// 読めた .ylsmart を core の素材にできなかった理由から、置けない理由へ。画像・Generator の再固定は文言で見分け、
/// それ以外は、core が持てない中身があればその一覧（読めている素材を「読めません」とは言わない）、なければ読めなかった理由。
fn smart_block(file: &SmartFile, e: &yolu_io::Error) -> Block {
    match block_from(e) {
        Block::Unreadable(_) => {
            let issues = file.fragment().core_issues();
            if issues.is_empty() {
                Block::Unreadable(Unreadable::from_error(e))
            } else {
                Block::Unsupported(Unreadable {
                    ja: Lang::Ja.unsupported_features(&issues),
                    en: Lang::En.unsupported_features(&issues),
                })
            }
        }
        block => block,
    }
}

/// 素材の絵（長い辺が `THUMB`。文書の合成の参照の式で標本化する。マスクは見せる量の灰色）。
fn smart_picture(material: &SmartMaterial) -> Option<Picture> {
    let (w, h) = (material.width(), material.height());
    let (tw, th) = fit_size(w, h);
    let mut rgba = Vec::with_capacity((tw * th) as usize * 4);
    let sample = |tx: u32, ty: u32| {
        let x = (((tx as f32 + 0.5) * w as f32 / tw as f32) as u32).min(w - 1);
        // 画像は上の行から、文書は下の行から
        let y = h - 1 - (((ty as f32 + 0.5) * h as f32 / th as f32) as u32).min(h - 1);
        (x, y)
    };
    if material.kind() == SmartKind::Mask {
        let mask = material.layers().first()?.mask()?;
        for ty in 0..th {
            for tx in 0..tw {
                let (x, y) = sample(tx, ty);
                let f = mask.factor_at(x, y).unwrap_or(1.0).clamp(0.0, 1.0);
                let g = (f * 255.0).round() as u8;
                rgba.extend_from_slice(&[g, g, g, 255]);
            }
        }
    } else {
        let doc = material.fragment_document().ok()?;
        let channels = material.channels();
        let channel = if channels.is_empty() || channels.contains(&Channel::Color) {
            Channel::Color
        } else {
            channels[0]
        };
        for ty in 0..th {
            for tx in 0..tw {
                let (x, y) = sample(tx, ty);
                let p = doc
                    .composite_pixel(channel, x, y)
                    .map(|p| p.to_array())
                    .unwrap_or([0; 4]);
                rgba.extend_from_slice(&p);
            }
        }
    }
    Some(Picture {
        width: tw,
        height: th,
        rgba,
    })
}

// ───────── 操作 ─────────

/// 置く先。
#[derive(Clone, Debug, PartialEq)]
pub enum PlaceTarget {
    /// 選んでいるレイヤーの上（スマートマスクは選んでいるレイヤーのマスク）。
    Selected,
    /// レイヤーの一覧の落とした所（親のグループと、その子の中の位置。0 が一番下。None の位置は一番上）。
    At {
        parent: Option<LayerId>,
        position: Option<usize>,
    },
    /// このレイヤーのマスクへ（スマートマスク）。
    Mask(LayerId),
}

/// 棚の操作（棚の中身を変えるもの・文書へ置くもの）。文書を変えるのは `Place` だけで、1 回の Undo。
#[derive(Clone, Debug, PartialEq)]
pub enum ShelfOp {
    /// レイヤー（グループなら中身ごと）をスマートマテリアルとして棚へ。
    SaveMaterial(LayerId),
    /// レイヤーのマスクをスマートマスクとして棚へ。
    SaveMask(LayerId),
    Place {
        id: String,
        target: PlaceTarget,
    },
    /// 棚から消す（消す前に確かめるウィンドウは `AskRemove`）。
    Remove(String),
    AskRemove(String),
    /// 別のスレッドで書き出している保存をやめる（できた素材は棚へ入れない）。
    CancelSave,
    /// 外の .ylsmart を棚へ。
    ImportFile(PathBuf),
    /// 外の .ylsmart をまとめて棚へ（入れた数と断ったファイルの理由を 1 つの知らせにする）。
    ImportFiles(Vec<PathBuf>),
    ImportDialog,
    /// 棚の素材を .ylsmart のファイルへ。
    ExportFile {
        id: String,
        path: PathBuf,
    },
    ExportDialog(String),
    /// 棚の素材（プロジェクトの棚の ID）を個人のライブラリへ入れる（別のスレッドで書く。同じバイト列があれば書かない）。
    ToLibrary(String),
    /// ライブラリのファイル（相対パス）をこのプロジェクトで使う＝写しを .ylp の棚へ入れる（別のスレッドで読んで検証する）。
    UseFromLibrary(String),
    /// ライブラリのファイルを消してよいか確かめる／消す（ファイルだけ。プロジェクトの写しと置いたレイヤーは変わらない）。
    LibraryAskRemove(String),
    LibraryRemove(String),
    /// ライブラリへファイル（PNG・.ylsmart）を足す（別のスレッドで検証して書く）／足すファイルを選ぶウィンドウを開く。
    LibraryAddFiles(Vec<PathBuf>),
    LibraryAddDialog,
    /// ライブラリのフォルダを OS のファイルのウィンドウで開く。
    LibraryReveal,
    /// ライブラリの一覧を読み直す。
    LibraryRefresh,
    /// 塗りつぶしレイヤーをマテリアルとして個人のライブラリへ書く（`.ylmaterial`。別のスレッドで書く。文書と棚は変えない）。
    SaveAsMaterial(LayerId),
}

/// 棚へ入れた結果（新しく入ったか、同じ中身が既にあったか）。
enum Kept {
    Added,
    Existing,
}

/// レイヤーの一覧へ落としている棚の素材（egui のドラッグの荷物）。
#[derive(Clone, Debug, PartialEq)]
pub struct ShelfDrag {
    pub id: String,
    pub kind: ItemKind,
    pub name: String,
}

/// 棚の画像を、1 枚のペイントのレイヤーの素材にする（置くときに文書の大きさへ引き伸ばす。置くのは 1 回の Undo のレイヤーの挿入と同じ道）。
/// 画素は straight RGBA8 のまま（透明の画素の RGB も保つ）。読めない・大きさが索引と違うときの理由は棚の画像の言葉で言う。
pub(crate) fn image_as_material(
    lang: Lang,
    png: &[u8],
    width: u32,
    height: u32,
    name: &str,
) -> Result<SmartMaterial, String> {
    let unreadable = || lang.t("shelf-cannot-read-the-image").to_owned();
    let reader =
        image::ImageReader::with_format(std::io::Cursor::new(png), image::ImageFormat::Png);
    let (found_w, found_h) = reader.into_dimensions().map_err(|_| unreadable())?;
    if (found_w, found_h) != (width, height) {
        return Err(lang.t("shelf-image-size-differs-from-the").to_owned());
    }
    let (mut doc, note) = crate::project::preview_document(Some(png), width, height, lang);
    if note.is_some() {
        return Err(unreadable());
    }
    let id = doc
        .layers()
        .first()
        .map(|l| l.id())
        .ok_or_else(|| lang.t("shelf-layer-not-found").to_owned())?;
    doc.set_layer_name(id, name)
        .map_err(|e| lang.core_error(&e))?;
    doc.capture_smart_material(&[id], name)
        .map_err(|e| lang.core_error(&e))
}

/// .ylsmart のバイト列を、置ける core の素材にする。読めた素材を置けないときは、項目に出す理由と同じ言い方で断る。
pub(crate) fn smart_material_from(lang: Lang, bytes: &[u8]) -> Result<SmartMaterial, String> {
    match SmartFile::read(bytes) {
        Err(e) => Err(crate::lang::shelf_io_error(lang, &e)),
        Ok(file) => file.to_core().map_err(|e| match smart_block(&file, &e) {
            Block::Unreadable(_) => crate::lang::shelf_io_error(lang, &e),
            block => block.reason(lang),
        }),
    }
}

/// 新しい素材の ID（小文字のハイフン付き GUID。文書の ID の作り方と同じ乱数）。
fn new_resource_id() -> String {
    let doc = Document::new(1, 1).expect("1×1 の文書");
    crate::sets::guid_string(doc.id())
}

/// 素材の保存・ライブラリからの取り込み（閉じる前の確かめ・止める。やめた保存のスレッドも、終わるまで待つ）。
pub(crate) const JOB: JobSpec = JobSpec {
    close: Some(|app| match app.shelf.pending_save() {
        Some(true) => Some(CloseJob::ShelfImport),
        Some(false) => Some(CloseJob::ShelfSave),
        None => None,
    }),
    cancel: Some(AppState::cancel_shelf_save),
    ..JobSpec::new("shelf", |app| app.shelf.saves_running() > 0)
};

impl AppState {
    /// ライブラリのフォルダへの書き込みをやめる（スレッドは次の区切りまで走る）。
    pub(crate) fn cancel_library_write(&mut self) {
        if let Some(w) = self.library.write.take() {
            self.info(
                Source::Assets,
                format!("{}: {}", self.lang.t("shelf-cancelled-writing"), w.name),
            );
        }
    }

    /// 素材の保存・ライブラリからの取り込みをやめる（スレッドは次の区切りまで走る）。
    pub(crate) fn cancel_shelf_save(&mut self) {
        if let Some(p) = self.shelf.saving.take() {
            self.info(
                Source::Assets,
                format!(
                    "{}: {}",
                    if p.from_library {
                        self.lang.t("shelf-cancelled-importing")
                    } else {
                        self.lang.t("shelf-cancelled-saving")
                    },
                    p.name
                ),
            );
        }
    }

    /// 棚の操作を当てる。断られたら何も変えず、理由をステータスバーへ。
    pub fn shelf_apply(&mut self, op: ShelfOp) {
        // 書き出しをやめるのは、描いている間でもできる（棚にも文書にも触らない）
        if op == ShelfOp::CancelSave {
            self.cancel_library_write();
            self.cancel_shelf_save();
            return;
        }
        if self.is_stroking() {
            self.refuse(
                Source::Assets,
                crate::lang::refusals::during_stroke(self.lang),
            );
            return;
        }
        self.shelf.use_language(self.lang);
        // 同梱の素材は棚に入っていない: 消す・書き出すは断る（置くだけ）
        if let ShelfOp::Remove(id)
        | ShelfOp::AskRemove(id)
        | ShelfOp::ExportDialog(id)
        | ShelfOp::ExportFile { id, .. } = &op
        {
            if is_builtin(id) {
                let reason = match op {
                    ShelfOp::Remove(_) | ShelfOp::AskRemove(_) => {
                        self.lang.t("shelf-built-in-items-cannot-be")
                    }
                    _ => self.lang.t("shelf-built-in-items-cannot-be-2"),
                };
                return self.refuse(Source::Assets, self.lang.with_reason(reason, ""));
            }
        }
        match op {
            ShelfOp::SaveMaterial(id) => self.shelf_save(id, false),
            ShelfOp::SaveMask(id) => self.shelf_save(id, true),
            ShelfOp::Place { id, target } => self.shelf_place(&id, target),
            ShelfOp::CancelSave => {}
            ShelfOp::Remove(id) => {
                if !self.shelf_refuse_while_saving() {
                    self.shelf_remove(&id)
                }
            }
            ShelfOp::AskRemove(id) => {
                if self.shelf.get(&id).is_some() && !self.shelf_refuse_while_saving() {
                    // 使われている画像は、確認のウィンドウを出す前に断る（確かめても消せない）
                    if let Some(why) = self.shelf_image_in_use(&id) {
                        self.refuse(Source::Assets, why);
                    } else {
                        self.shelf.pending_remove = Some(id);
                        self.outbox.dialog_request = Some(DialogRequest::ShelfRemove);
                    }
                }
            }
            ShelfOp::ImportFile(path) => {
                if !self.shelf_refuse_while_saving() {
                    self.shelf_import(&[path])
                }
            }
            ShelfOp::ImportFiles(paths) => {
                if !self.shelf_refuse_while_saving() {
                    self.shelf_import(&paths)
                }
            }
            ShelfOp::ImportDialog => {
                if !self.shelf_refuse_while_saving() {
                    self.outbox.dialog_request = Some(DialogRequest::ShelfImport)
                }
            }
            ShelfOp::ExportFile { id, path } => self.shelf_export(&id, &path),
            ShelfOp::ExportDialog(id) => {
                if self.shelf.get(&id).is_some() {
                    self.shelf.export_id = Some(id);
                    self.outbox.dialog_request = Some(DialogRequest::ShelfExport);
                }
            }
            ShelfOp::ToLibrary(id) => self.library_put(&id),
            ShelfOp::UseFromLibrary(rel) => self.library_use(&rel),
            ShelfOp::LibraryAskRemove(rel) => self.library_ask_remove(&rel),
            ShelfOp::LibraryRemove(rel) => self.library_remove(&rel),
            ShelfOp::LibraryAddFiles(paths) => self.library_add_files(&paths),
            ShelfOp::LibraryAddDialog => {
                if self.library_idle() {
                    self.outbox.dialog_request = Some(DialogRequest::LibraryAdd);
                }
            }
            ShelfOp::LibraryReveal => {
                self.outbox.dialog_request = Some(DialogRequest::LibraryReveal)
            }
            ShelfOp::LibraryRefresh => self.library.refresh(),
            ShelfOp::SaveAsMaterial(id) => self.library_save_material(id),
        }
    }

    /// 棚とライブラリの断りと失敗を、何が（`attempt` と名前）できないかと、その理由の 1 つの文で知らせる（`kind` は断りか失敗か）。
    pub(crate) fn cannot(
        &mut self,
        kind: NoticeKind,
        source: Source,
        attempt: Attempt,
        name: Option<&str>,
        reason: &str,
    ) {
        let text = self.lang.with_reason(attempt.what(self.lang, name), reason);
        self.notify(kind, source, text);
    }

    /// 別のスレッドの保存が棚の写しへ足している間は、棚を変える操作（消す・読み込む）を断る（保存の結果は足した後の棚に
    /// 差し替えるので、その間に棚が変わると、変えた分が消える）。断ったら true。
    pub(crate) fn shelf_refuse_while_saving(&mut self) -> bool {
        if self.shelf.saving.is_none() {
            return false;
        }
        let reason = self.lang.t("shelf-already-saving");
        self.cannot(
            NoticeKind::Refusal,
            Source::Assets,
            Attempt::ShelfChange,
            None,
            reason,
        );
        true
    }

    /// 棚を変えてよいか（読めなかった棚には足さない・消さない）。
    pub(crate) fn shelf_writable(&mut self) -> bool {
        match self.shelf.unavailable.clone() {
            Some(e) => {
                let lang = self.lang;
                self.fail(
                    Source::Assets,
                    lang.with_reason(lang.t("shelf-cannot-change-the-project-s"), e.reason(lang)),
                );
                false
            }
            None => true,
        }
    }

    fn shelf_save(&mut self, id: LayerId, mask: bool) {
        let lang = self.lang;
        if let Some(reason) = self.read_only_reason() {
            let text = crate::lang::refusals::read_only_set(lang, reason);
            self.refuse(Source::Assets, text);
            return;
        }
        if !self.shelf_writable() {
            return;
        }
        // 書き出しが走っている間は、捕まえる写し（大きな素材では数百 MiB）を作る前に断る
        if let Some(reason) = self.shelf.busy_reason(lang) {
            return self.cannot(
                NoticeKind::Refusal,
                Source::Assets,
                Attempt::ShelfSave,
                None,
                reason,
            );
        }
        // 捕まえるたびに別の素材になる（同じ中身が既にあって足りることは無い）ので、いっぱいの棚には写しを作る前に断る
        if self.shelf.shelf.resources().len() >= MAX_RESOURCES {
            return self.cannot(
                NoticeKind::Refusal,
                Source::Assets,
                Attempt::ShelfSave,
                None,
                crate::lang::refusals::shelf_full(lang),
            );
        }
        let Some(layer_name) = self.session.doc.layer(id).map(|l| l.name().to_owned()) else {
            return self.cannot(
                NoticeKind::Refusal,
                Source::Assets,
                Attempt::ShelfSave,
                None,
                lang.t("shelf-layer-not-found"),
            );
        };
        let name = if mask {
            format!("{layer_name}{}", lang.t("shelf-mask"))
        } else {
            layer_name
        };
        let captured = if mask {
            self.session.doc.capture_smart_mask(id, &name)
        } else {
            self.session.doc.capture_smart_material(&[id], &name)
        };
        let material = match captured {
            Ok(m) => m,
            Err(e) => {
                return self.cannot(
                    NoticeKind::of_core(&e),
                    Source::Assets,
                    Attempt::ShelfSave,
                    Some(&name),
                    &lang.core_error(&e),
                )
            }
        };
        let kind = if mask {
            ItemKind::SmartMask
        } else {
            ItemKind::SmartMaterial
        };
        // 大きな素材、または大きな棚への保存は、書き出し（正本への変換・圧縮・サムネイル）と棚への追加（棚全体の検証）を別のスレッドで行い、
        // 画面のスレッドには差し替えだけを残す。捕まえた写しは文書から独立、棚の写しは中身を共有する（保存の間、棚を変える操作は断る）
        if material
            .pixel_bytes()
            .saturating_add(self.shelf.shelf.used_bytes())
            >= self.shelf.async_bytes
        {
            let (tx, rx) = std::sync::mpsc::channel();
            let repaint = self.shelf.waker.clone();
            let hold = self.shelf.hold.clone();
            let cancel = Arc::new(AtomicBool::new(false));
            let running = Running::start(&self.shelf.running);
            let thread_cancel = cancel.clone();
            let snapshot = self.shelf.shelf.clone();
            let thread_name = name.clone();
            std::thread::spawn(move || {
                let done = encode_material(&material, Some(&thread_cancel)).and_then(|encoded| {
                    if thread_cancel.load(Ordering::SeqCst) {
                        return Err(yolu_io::Error::Core(CoreError::Cancelled));
                    }
                    stage(snapshot, &thread_name, kind, encoded)
                });
                while hold.load(Ordering::SeqCst) {
                    std::thread::sleep(std::time::Duration::from_millis(1));
                }
                // 結果を渡す前に数えから外す（結果を受けた直後の保存が、終わりかけのスレッドのせいで断られない）
                drop(running);
                let _ = tx.send(done);
                if let Some(waker) = repaint {
                    waker.wake();
                }
            });
            self.info(
                Source::Assets,
                format!("{}: {name}", lang.t("shelf-saving")),
            );
            self.shelf.saving = Some(PendingSave {
                name,
                kind,
                rx,
                cancel,
                from_library: false,
            });
            return;
        }
        match encode_material(&material, None) {
            Ok(done) => self.shelf_keep(&name, kind, done),
            Err(e) => self.cannot(
                NoticeKind::Error,
                Source::Assets,
                Attempt::ShelfSave,
                Some(&name),
                &crate::lang::shelf_io_error(lang, &e),
            ),
        }
    }

    /// 書き出した素材を棚へ入れる（同じ中身が既にあればそれ）。入れたら選び、サムネイルを覚える。知らせは 1 件分を出す。
    fn shelf_keep(&mut self, name: &str, kind: ItemKind, done: Encoded) {
        match self.shelf_keep_quiet(name, kind, done) {
            Ok(kept) => self.shelf_keep_message(name, kept),
            Err(reason) => self.cannot(
                NoticeKind::Error,
                Source::Assets,
                Attempt::ShelfSave,
                Some(name),
                &reason,
            ),
        }
    }

    fn shelf_keep_message(&mut self, name: &str, kept: Kept) {
        let lang = self.lang;
        self.info(
            Source::Assets,
            match kept {
                Kept::Added => format!("{}: {name}", lang.t("shelf-added-to-the-project-s")),
                Kept::Existing => format!("{}: {name}", lang.t("shelf-already-in-the-project-s")),
            },
        );
    }

    /// `shelf_keep` の知らせを出さない形（まとめて読み込むときに、知らせを 1 つにまとめるため）。断りは理由だけ（名前は呼ぶ側が添える）。
    /// 棚の検証はこのスレッドで行う（読み込みは同期。大きな棚では長い）。
    fn shelf_keep_quiet(
        &mut self,
        name: &str,
        kind: ItemKind,
        done: Encoded,
    ) -> Result<Kept, String> {
        let lang = self.lang;
        let staged = stage(self.shelf.shelf.clone(), name, kind, done)
            .map_err(|e| crate::lang::shelf_io_error(lang, &e))?;
        Ok(self.shelf_adopt(name, kind, staged))
    }

    /// 足した後の棚に差し替える（足していなければそのまま）。入れた素材は絞り込み・検索で隠さず、選ぶ。
    fn shelf_adopt(&mut self, name: &str, kind: ItemKind, staged: Staged) -> Kept {
        if staged.added {
            self.shelf.shelf = staged.next;
            if let Some(info) = staged.info {
                self.shelf.inspected.insert(staged.id.clone(), info);
            }
            self.shelf.changed = true;
            self.session.mark_modified();
        }
        self.shelf_reveal(&staged.id, kind, name);
        if staged.added {
            Kept::Added
        } else {
            Kept::Existing
        }
    }

    /// ライブラリのファイルを取り込んだ棚に差し替える（足していなければそのまま）。見せている一覧（絞り込み・検索）は変えず、
    /// 取り込んだ素材をプロジェクトの棚で選んでおく。
    fn shelf_adopt_quiet(&mut self, staged: Staged) -> Kept {
        if staged.added {
            self.shelf.shelf = staged.next;
            if let Some(info) = staged.info {
                self.shelf.inspected.insert(staged.id.clone(), info);
            }
            self.shelf.changed = true;
            self.session.mark_modified();
        }
        self.shelf.selected = Some(staged.id);
        if staged.added {
            Kept::Added
        } else {
            Kept::Existing
        }
    }

    /// 別のスレッドの書き出しが終わっていれば棚へ入れる（毎フレーム）。
    pub fn shelf_poll(&mut self) {
        let lang = self.lang;
        let Some(pending) = &self.shelf.saving else {
            return;
        };
        // スレッドが結果を渡さずに終わった（パニック）ときも、断りとして出す
        let result = match pending.rx.try_recv() {
            Ok(r) => Some(r.map_err(|e| crate::lang::shelf_io_error(lang, &e))),
            Err(std::sync::mpsc::TryRecvError::Empty) => None,
            Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                Some(Err(lang.t("shelf-the-write-stopped-midway").to_owned()))
            }
        };
        if let Some(result) = result {
            let pending = self.shelf.saving.take().expect("上で確かめた");
            match result {
                Ok(staged) if pending.from_library => {
                    let rounded = staged.rounded;
                    let kept = self.shelf_adopt_quiet(staged);
                    let name = &pending.name;
                    self.info(
                        Source::Assets,
                        match kept {
                            Kept::Added => format!(
                                "{}: {name}{}",
                                lang.t("shelf-added-to-the-project"),
                                if rounded {
                                    format!(" · {}", crate::library::rounded_note(lang))
                                } else {
                                    String::new()
                                }
                            ),
                            Kept::Existing => {
                                format!("{}: {name}", lang.t("shelf-already-in-the-project"))
                            }
                        },
                    );
                }
                Ok(staged) => {
                    let kept = self.shelf_adopt(&pending.name, pending.kind, staged);
                    self.shelf_keep_message(&pending.name, kept);
                }
                Err(reason) => self.cannot(
                    NoticeKind::Error,
                    Source::Assets,
                    if pending.from_library {
                        Attempt::LibraryUse
                    } else {
                        Attempt::ShelfSave
                    },
                    Some(&pending.name),
                    &reason,
                ),
            }
        }
    }

    /// 別のスレッドの書き出しが終わるまで待って棚へ入れる（試験用）。
    pub fn shelf_wait(&mut self) {
        while self.shelf.saving.is_some() {
            self.shelf_poll();
            std::thread::sleep(std::time::Duration::from_millis(2));
        }
    }

    /// 入れた素材が絞り込み・検索で隠れないようにして選ぶ。
    fn shelf_reveal(&mut self, id: &str, kind: ItemKind, name: &str) {
        if self.shelf.filter.is_some_and(|f| f != kind) {
            self.shelf.filter = Some(kind);
        }
        let needle = self.shelf.search.trim().to_lowercase();
        if !needle.is_empty() && !name.to_lowercase().contains(&needle) {
            self.shelf.search.clear();
        }
        self.shelf.selected = Some(id.to_owned());
    }

    fn shelf_place(&mut self, id: &str, target: PlaceTarget) {
        let lang = self.lang;
        // ライブラリのファイルは、棚へ入れずに、読んで置く
        if let Some(rel) = crate::library::rel_of(id) {
            return self.library_place(rel, target);
        }
        let Some(res) = self.shelf.get(id) else {
            return;
        };
        let name = res.name.clone();
        let kind = ItemKind::of(&res.kind);
        let (width, height) = (
            res.metadata["width"].as_u64().unwrap_or(0) as u32,
            res.metadata["height"].as_u64().unwrap_or(0) as u32,
        );
        if !kind.is_some_and(|k| k.is_smart_file() || k == ItemKind::Image) {
            let block = Block::Kind(kind.unwrap_or(ItemKind::Brush));
            return self.refuse(Source::Assets, lang.with_reason(block.reason(lang), ""));
        }
        let builtin = is_builtin(id);
        let bytes = if builtin {
            &[][..]
        } else {
            let Some(bytes) = self.shelf.shelf.content_bytes(id) else {
                return;
            };
            bytes
        };
        let made = if builtin {
            // 同梱の素材はコードから組む（ファイルも棚の中身も無い）
            self.shelf
                .build_builtin(id, lang)
                .ok_or_else(|| lang.t("shelf-cannot-build-the-built-in").to_owned())
        } else if kind == Some(ItemKind::Image) {
            image_as_material(lang, bytes, width, height, &name)
        } else {
            smart_material_from(lang, bytes)
        };
        let material = match made {
            Ok(m) => m,
            Err(reason) => {
                return self.cannot(
                    NoticeKind::Error,
                    Source::Assets,
                    Attempt::Place,
                    Some(&name),
                    &reason,
                )
            }
        };
        self.place_material(&name, material, target, builtin);
    }

    /// 組み上がった素材を文書へ置く（スマートマスクはレイヤーのマスクへ、スマートマテリアルはレイヤーの組として。1 回の Undo）。棚の項目も、
    /// ライブラリのファイルも、この道を通る。置けないときは何も変えず、理由を短く出す。
    pub(crate) fn place_material(
        &mut self,
        name: &str,
        material: SmartMaterial,
        target: PlaceTarget,
        builtin: bool,
    ) {
        let lang = self.lang;
        if material.kind() == SmartKind::Mask {
            let layer = match target {
                PlaceTarget::Mask(layer) => Some(layer),
                _ => self.session.selected_layer,
            };
            let Some(layer) = layer.filter(|l| self.session.doc.layer(*l).is_some()) else {
                return self.cannot(
                    NoticeKind::Refusal,
                    Source::Assets,
                    Attempt::Place,
                    Some(name),
                    lang.t("shelf-no-layer-selected"),
                );
            };
            let had_mask = self
                .session
                .doc
                .layer(layer)
                .is_some_and(|l| l.mask().is_some());
            match self.session.doc.apply_smart_mask(&material, layer, None) {
                Ok(result) => {
                    self.session.selected_layer = Some(layer);
                    self.set_edit_mask(true);
                    self.session.mark_modified();
                    let mut text = format!(
                        "{}: {name}",
                        if had_mask {
                            lang.t("shelf-replaced-the-mask")
                        } else {
                            lang.t("shelf-applied-as-the-mask")
                        }
                    );
                    text += &resized_note(lang, &material, result.resampled);
                    self.info(Source::Assets, text);
                }
                Err(e) => self.cannot(
                    NoticeKind::of_core(&e),
                    Source::Assets,
                    Attempt::Place,
                    Some(name),
                    &lang.core_error(&e),
                ),
            }
            self.ensure_selection();
            return;
        }
        let (parent, position) = match target {
            PlaceTarget::At { parent, position } => (parent, position),
            _ => self.above_selected_slot(),
        };
        // 一番上の段に置くときは、今のレイヤーセットへ（一覧に出ているのは今のレイヤーセットのレイヤーだけで、位置もその中で数えている）
        let placement = SmartPlacement {
            parent,
            set: parent.is_none().then(|| self.layer_set()),
            position,
            ..SmartPlacement::default()
        };
        match self.session.doc.place_smart_material(&material, &placement) {
            Ok(result) => {
                self.session.selected_layer = Some(result.layer_id);
                self.set_edit_mask(false);
                if let Some(p) = parent {
                    self.m2.collapsed.remove(&p);
                }
                self.session.mark_modified();
                let n = result.layers.len();
                let mut text = format!(
                    "{}: {name}（{}",
                    lang.t("shelf-placed"),
                    lang.f("shelf-layer-count", &[("n", &Count(n))])
                );
                // 同梱の素材は大きさに依らない（画素が無い）ので、変えたとは言わない
                text += &resized_note(lang, &material, result.resampled && !builtin);
                text += "）";
                self.info(Source::Assets, text);
            }
            Err(e) => self.cannot(
                NoticeKind::of_core(&e),
                Source::Assets,
                Attempt::Place,
                Some(name),
                &lang.core_error(&e),
            ),
        }
        self.ensure_selection();
    }

    /// 選んでいるレイヤーのすぐ上の置き場所（親と、その子の中の位置。選んだレイヤーが無ければ一番上）。
    fn above_selected_slot(&self) -> (Option<LayerId>, Option<usize>) {
        let Some((id, parent, set)) = self.session.selected_layer.and_then(|id| {
            self.session
                .doc
                .layer(id)
                .map(|l| (id, l.parent(), l.layer_set()))
        }) else {
            return (None, None);
        };
        // 位置は、選んだレイヤーのレイヤーセットの中で数える
        let siblings = self
            .session
            .doc
            .children_in_set(set, parent)
            .unwrap_or_default();
        (
            parent,
            siblings.iter().position(|c| *c == id).map(|i| i + 1),
        )
    }

    /// 棚の画像をレイヤーが読んでいれば、消せない理由の文（読んでいなければ None。画像でない素材も None）。読み込んだプロジェクトの
    /// 原本のレイヤーと、いまのセッションの全部のテクスチャセットのレイヤーを見る。消すと、レイヤーは棚に無い画像を指し、保存して開き直すとそのセットは
    /// 読むだけになる。取り消しの履歴の中にだけあるレイヤー（消したレイヤーを Undo で戻す）は見ない。
    fn shelf_image_in_use(&self, id: &str) -> Option<String> {
        let res = self.shelf.get(id).filter(|r| r.kind == "image")?;
        let lang = self.lang;
        let project = self.session.project.as_ref().map(|p| p.project());
        let users = crate::fillfx::image_users(self, id);
        if users.is_empty() && !self.shelf.used_by(project, id) {
            return None;
        }
        let what = lang.f(
            "shelf-cannot-remove-because-a-layer",
            &[("name", &lang.quote(&res.name))],
        );
        let list = users.iter().take(3).cloned().collect::<Vec<_>>().join(", ");
        let more = if users.len() > 3 { " …" } else { "" };
        Some(lang.with_reason(&what, format!("{list}{more}")))
    }

    fn shelf_remove(&mut self, id: &str) {
        let lang = self.lang;
        if !self.shelf_writable() {
            return;
        }
        let Some(res) = self.shelf.get(id) else {
            return;
        };
        let name = res.name.clone();
        if let Some(why) = self.shelf_image_in_use(id) {
            return self.refuse(Source::Assets, why);
        }
        match self.shelf.shelf.remove(id) {
            Ok(true) => {
                self.shelf.inspected.remove(id);
                if self.shelf.selected.as_deref() == Some(id) {
                    self.shelf.selected = None;
                }
                self.shelf.changed = true;
                self.session.mark_modified();
                self.info(
                    Source::Assets,
                    format!("{}: {name}", lang.t("shelf-removed-from-the-project-s")),
                );
            }
            Ok(false) => {}
            Err(e) => self.cannot(
                NoticeKind::Error,
                Source::Assets,
                Attempt::ShelfRemove,
                Some(&name),
                &crate::lang::shelf_io_error(lang, &e),
            ),
        }
        if self.shelf.pending_remove.as_deref() == Some(id) {
            self.shelf.pending_remove = None;
        }
    }

    /// 外の .ylsmart を棚へ（1 つでも複数でも、知らせは 1 つ。断ったファイルは名前と理由を残し、後ろの成功で消さない）。
    fn shelf_import(&mut self, paths: &[PathBuf]) {
        let lang = self.lang;
        if !self.shelf_writable() {
            return;
        }
        let (mut added, mut existing) = (Vec::new(), Vec::new());
        let mut refused = Vec::new();
        for path in paths {
            match self.shelf_import_one(path) {
                Ok((name, Kept::Added)) => added.push(name),
                Ok((name, Kept::Existing)) => existing.push(name),
                Err(refusal) => refused.push(refusal),
            }
        }
        let (new, old) = (added.len(), existing.len());
        if refused.is_empty() {
            let text = match (added.as_slice(), existing.as_slice()) {
                ([name], []) => format!("{}: {name}", lang.t("shelf-added-to-the-project-s")),
                ([], [name]) => format!("{}: {name}", lang.t("shelf-already-in-the-project-s")),
                _ => kept_note(lang, new, old),
            };
            if new + old > 0 {
                self.info(Source::Assets, text);
            }
            return;
        }
        // 断りがあっても、入れた分とすでにあった分は別に数える（すでにあったものを「入れました」と言わない）
        let mut text = refused.join(lang.t("shelf-text"));
        if new + old > 0 {
            // 一部は入った（入れた分・すでにあった分）: 気をつけること。全部断ったなら失敗
            text += lang.t("shelf-text");
            text += &kept_note(lang, new, old);
            self.warn(Source::Assets, text);
        } else {
            self.fail(Source::Assets, text);
        }
    }

    /// 1 つの .ylsmart を棚へ。入れた名前と、新しく入ったか。断りは、ファイル名と理由を言う 1 つの文。
    fn shelf_import_one(&mut self, path: &std::path::Path) -> Result<(String, Kept), String> {
        let lang = self.lang;
        let shown = path
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default();
        match std::fs::metadata(path) {
            Ok(m) if m.len() > self.shelf.import_limit => {
                return Err(refused(lang, &shown, lang.t("shelf-too-large")));
            }
            Ok(_) => {}
            Err(e) => return Err(refused(lang, &shown, &lang.file_error(&e))),
        }
        let bytes = match std::fs::read(path) {
            Ok(bytes) => bytes,
            Err(e) => return Err(refused(lang, &shown, &lang.file_error(&e))),
        };
        let file = match SmartFile::read(&bytes) {
            Ok(file) => file,
            Err(e) => {
                let file = lang.quote(&shown);
                return Err(lang.with_reason(
                    lang.f("shelf-is-not-a-readable-smart", &[("file", &file)]),
                    lang.io_error(&e),
                ));
            }
        };
        let kind = if file.kind() == SmartKind::Mask {
            ItemKind::SmartMask
        } else {
            ItemKind::SmartMaterial
        };
        let name = file.info()["name"].as_str().unwrap_or(&shown).to_owned();
        let kept = self
            .shelf_keep_quiet(&name, kind, Encoded { bytes, info: None })
            .map_err(|why| refused(lang, &shown, &why))?;
        Ok((name, kept))
    }

    fn shelf_export(&mut self, id: &str, path: &std::path::Path) {
        let lang = self.lang;
        let Some(res) = self.shelf.get(id) else {
            return;
        };
        let name = res.name.clone();
        if !ItemKind::of(&res.kind).is_some_and(ItemKind::is_smart) {
            return self.refuse(
                Source::Assets,
                lang.f(
                    "shelf-is-not-a-smart-asset",
                    &[("name", &lang.quote(&name))],
                ),
            );
        }
        let Some(bytes) = self.shelf.shelf.content_bytes(id) else {
            return;
        };
        // 置き換えは 1 回（一時ファイルへ書いて同期し、名前を付け替える。途中で失敗しても元のファイルは変わらない）
        let result = yolu_io::atomic::replace_bytes(path, bytes);
        match result {
            Ok(()) => self.info(
                Source::Assets,
                format!("{}: {}", lang.t("shelf-exported"), path.display()),
            ),
            Err(e) => {
                let target = lang.quote(&path.display().to_string());
                self.fail(
                    Source::Assets,
                    lang.with_reason(
                        lang.f("shelf-cannot-export-to", &[("target", &target)]),
                        lang.file_error(&e),
                    ),
                );
            }
        }
    }
}

/// 読み込みの結果の件数（入れた分とすでにあった分。0 の分は出さない）。
fn kept_note(lang: Lang, added: usize, existing: usize) -> String {
    let mut parts = Vec::new();
    if added > 0 {
        parts.push(lang.f("shelf-added-to-the-project-s-2", &[("added", &added)]));
    }
    if existing > 0 {
        parts.push(lang.f(
            "shelf-were-already-in-the-project",
            &[("existing", &Count(existing))],
        ));
    }
    parts.join(lang.t("shelf-text"))
}

/// アセットへ読み込めなかったファイルの 1 文（「「名前」をアセットに読み込めません（理由）。」）。
fn refused(lang: Lang, file: &str, why: &str) -> String {
    lang.with_reason(Attempt::ShelfImport.what(lang, Some(file)), why)
}

/// 棚とライブラリの断り・失敗の文の「何が」（何をしようとしてできなかったか）。名前があれば「「名前」を〜できません」の形。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Attempt {
    /// レイヤーを棚へ保存する（スマートマテリアル・スマートマスク）。
    ShelfSave,
    /// 外の .ylsmart を棚へ読み込む。
    ShelfImport,
    /// 棚を変える（保存の途中・棚を読めなかったとき）。
    ShelfChange,
    /// 棚から消す。
    ShelfRemove,
    /// 棚・ライブラリの素材を文書へ置く。
    Place,
    /// ライブラリのファイルをプロジェクトの棚へ取り込む。
    LibraryUse,
    /// ライブラリへ入れる（棚の素材・外のファイル）。
    LibraryAdd,
    /// ライブラリから消す。
    LibraryRemove,
    /// 塗りつぶしレイヤーをマテリアルとしてライブラリへ保存する。
    MaterialSave,
}

impl Attempt {
    /// 「〜できません」の文（句点なし）。
    pub(crate) fn what(self, lang: Lang, name: Option<&str>) -> String {
        let Some(name) = name else {
            return match self {
                Attempt::ShelfSave => lang.t("shelf-cannot-save-to-the-project"),
                Attempt::ShelfImport => lang.t("shelf-cannot-import-into-the-project"),
                Attempt::ShelfChange => lang.t("shelf-cannot-change-the-project-s-2"),
                Attempt::ShelfRemove => lang.t("shelf-cannot-remove-from-the-project"),
                Attempt::Place => lang.t("shelf-cannot-place-the-asset"),
                Attempt::LibraryUse => lang.t("shelf-cannot-import-from-the-library"),
                Attempt::LibraryAdd => lang.t("shelf-cannot-add-to-the-library"),
                Attempt::LibraryRemove => lang.t("shelf-cannot-remove-from-the-library"),
                Attempt::MaterialSave => lang.t("shelf-cannot-save-as-a-material"),
            }
            .to_owned();
        };
        let q = lang.quote(name);
        match lang {
            Lang::Ja => match self {
                Attempt::ShelfSave => format!("{q}をアセットに保存できません"),
                Attempt::ShelfImport => format!("{q}をアセットに読み込めません"),
                Attempt::ShelfChange => "アセットを変えられません".to_owned(),
                Attempt::ShelfRemove => format!("{q}をアセットから消せません"),
                Attempt::Place => format!("{q}を置けません"),
                Attempt::LibraryUse => format!("{q}をライブラリから取り込めません"),
                Attempt::LibraryAdd => format!("{q}をライブラリに入れられません"),
                Attempt::LibraryRemove => format!("{q}をライブラリから消せません"),
                Attempt::MaterialSave => format!("{q}をマテリアルとして保存できません"),
            },
            Lang::En => match self {
                Attempt::ShelfSave => format!("Cannot save {q} to the project's assets"),
                Attempt::ShelfImport => format!("Cannot import {q} into the project's assets"),
                Attempt::ShelfChange => "Cannot change the project's assets".to_owned(),
                Attempt::ShelfRemove => format!("Cannot remove {q} from the project's assets"),
                Attempt::Place => format!("Cannot place {q}"),
                Attempt::LibraryUse => format!("Cannot import {q} from the library"),
                Attempt::LibraryAdd => format!("Cannot add {q} to the library"),
                Attempt::LibraryRemove => format!("Cannot remove {q} from the library"),
                Attempt::MaterialSave => format!("Cannot save {q} as a material"),
            },
            Lang::Ko => match self {
                Attempt::ShelfSave => format!("프로젝트 에셋에 {q} 항목을 저장할 수 없습니다"),
                Attempt::ShelfImport => format!("프로젝트 에셋으로 {q} 항목을 가져올 수 없습니다"),
                Attempt::ShelfChange => "프로젝트 에셋을 변경할 수 없습니다".to_owned(),
                Attempt::ShelfRemove => format!("프로젝트 에셋에서 {q} 항목을 삭제할 수 없습니다"),
                Attempt::Place => format!("{q} 항목을 배치할 수 없습니다"),
                Attempt::LibraryUse => format!("라이브러리에서 {q} 항목을 가져올 수 없습니다"),
                Attempt::LibraryAdd => format!("라이브러리에 {q} 항목을 추가할 수 없습니다"),
                Attempt::LibraryRemove => format!("라이브러리에서 {q} 항목을 삭제할 수 없습니다"),
                Attempt::MaterialSave => format!("{q} 항목을 머티리얼로 저장할 수 없습니다"),
            },
        }
    }
}

/// 大きさが違って拡大縮小したときの知らせ（括弧の中に足す）。
fn resized_note(lang: Lang, material: &SmartMaterial, resampled: bool) -> String {
    if !resampled {
        return String::new();
    }
    match lang {
        Lang::Ja => format!("、{}×{} から変更", material.width(), material.height()),
        Lang::En => format!(", resized from {}×{}", material.width(), material.height()),
        Lang::Ko => format!(", {}×{}에서 크기 변경", material.width(), material.height()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_smart_materials_description_says_the_layer_count_once() {
        let info = |layers| Inspected {
            width: 8,
            height: 4,
            layers,
            ..Inspected::bare(None)
        };
        for (lang, one, three) in [
            (Lang::Ja, "1 レイヤー · 8 × 4", "3 レイヤー"),
            (Lang::En, "1 layer · 8 × 4", "3 layers"),
        ] {
            let one_layer = describe(lang, ItemKind::SmartMaterial, Some(&info(1)), (0, 0), false);
            assert_eq!(one_layer, one);
            let builtin = describe(lang, ItemKind::SmartMaterial, Some(&info(3)), (0, 0), true);
            assert_eq!(builtin, three);
        }
    }

    #[test]
    fn thumbnails_fit_the_long_side() {
        assert_eq!(fit_size(2048, 1024), (64, 32));
        assert_eq!(fit_size(3, 2), (64, 43));
        assert_eq!(fit_size(1, 4096), (1, 64));
        assert_eq!(fit_size(8, 8), (64, 64));
    }

    #[test]
    fn guid_text_matches_the_dotnet_layout() {
        let b = [
            0x44, 0x33, 0x22, 0x11, 0x66, 0x55, 0x88, 0x77, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee,
            0xff, 0x00,
        ];
        assert_eq!(guid_text(&b), "11223344-5566-7788-99aa-bbccddeeff00");
    }

    fn png(w: u32, h: u32) -> Vec<u8> {
        let mut out = Vec::new();
        image::RgbaImage::new(w, h)
            .write_to(&mut std::io::Cursor::new(&mut out), image::ImageFormat::Png)
            .unwrap();
        out
    }

    #[test]
    fn a_broken_or_mismatched_shelf_image_is_refused_in_the_shelfs_own_words() {
        let mut cut = png(2, 1);
        cut.truncate(cut.len() - 20);
        for (lang, unreadable, mismatch) in [
            (Lang::Ja, "画像を読めません", "画像の大きさが索引と違います"),
            (
                Lang::En,
                "Cannot read the image",
                "Image size differs from the index",
            ),
        ] {
            for bytes in [b"not a png".to_vec(), Vec::new(), cut.clone()] {
                let error = image_as_material(lang, &bytes, 2, 1, "x").unwrap_err();
                assert_eq!(error, unreadable);
            }
            // 大きさが索引と違う（どちら向きにも）
            for (w, h) in [(3, 1), (2, 2), (1, 1)] {
                let error = image_as_material(lang, &png(w, h), 2, 1, "x").unwrap_err();
                assert_eq!(error, mismatch, "{w}×{h}");
            }
            // 保存した合成の絵の話にはしない
            assert!(!unreadable.contains("合成") && !mismatch.contains("合成"));
            assert!(image_as_material(lang, &png(2, 1), 2, 1, "x").is_ok());
        }
    }

    fn picture(seed: u8) -> Picture {
        Picture {
            width: 2,
            height: 1,
            rgba: vec![seed, 2, 3, 0, 5, 6, seed, 255],
        }
    }

    fn cache_in(name: &str) -> (Cache, std::path::PathBuf) {
        let dir =
            std::env::temp_dir().join(format!("yolu-shelf-cache-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        (Cache::new(dir.clone()), dir)
    }

    #[test]
    fn a_remembered_picture_and_its_description_come_back_instead_of_being_made_again() {
        let (cache, dir) = cache_in("again");
        let key = Cache::key("smart", "abc");
        let made = || {
            let mut info = Inspected::bare(None);
            info.width = 3;
            info.height = 2;
            info.layers = 2;
            info.channels = vec![Channel::Color, Channel::Roughness];
            (info.with_picture(picture(9)), Some(SmartKind::Mask))
        };
        let (first, kind) = remembered(Some(&cache), &key, || false, made);
        assert_eq!(kind, Some(SmartKind::Mask));
        assert_eq!(cache.usage().0, 1);
        let (again, kind) = remembered(
            Some(&cache),
            &key,
            || false,
            || panic!("覚えているので作り直さない"),
        );
        assert_eq!(kind, Some(SmartKind::Mask));
        assert_eq!(
            (again.width, again.height, again.layers, &again.channels),
            (first.width, first.height, first.layers, &first.channels)
        );
        assert_eq!(
            again.picture(),
            Some(&picture(9)),
            "透明な画素の RGB も同じ"
        );
        // 覚えるのは、置けない理由が無く、絵のあるものだけ
        let blocked = Cache::key("smart", "blocked");
        remembered(
            Some(&cache),
            &blocked,
            || false,
            || (Inspected::bare(Some(Block::Images)), None),
        );
        let bare = Cache::key("smart", "bare");
        remembered(
            Some(&cache),
            &bare,
            || false,
            || (Inspected::bare(None), None),
        );
        assert_eq!(cache.usage().0, 1);
        // 取り消されたら（結果は捨てられるので）覚えない
        let stopped = Cache::key("smart", "stopped");
        remembered(Some(&cache), &stopped, || true, || (made().0, None));
        assert_eq!(cache.usage().0, 1);
        // キャッシュが無ければ、いつも作る
        let (info, _) = remembered(None, &key, || false, made);
        assert_eq!(info.layers, 2);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn the_description_kept_with_a_picture_reads_back_even_if_a_line_is_missing_or_unknown() {
        let cached = Cached {
            info: "w=7\nfuture=1\nlayers=oops\nchannels=Color,Bogus\nkind=other\n".into(),
            width: 1,
            height: 1,
            rgba: vec![1, 2, 3, 4],
        };
        let (info, kind) = from_cached(cached);
        assert_eq!((info.width, info.height, info.layers), (7, 0, 0));
        assert_eq!(info.channels, [Channel::Color]);
        assert_eq!(kind, None);
        assert_eq!(
            info.picture().map(|p| p.rgba.clone()),
            Some(vec![1, 2, 3, 4])
        );
    }

    #[test]
    fn kinds_round_trip_the_index_names() {
        for k in ItemKind::ALL {
            let name = match k {
                ItemKind::Image => "image",
                ItemKind::Brush => "brush",
                ItemKind::Material => "material",
                ItemKind::SmartMaterial => "smartMaterial",
                ItemKind::SmartMask => "smartMask",
            };
            assert_eq!(ItemKind::of(name), Some(k));
        }
        assert_eq!(ItemKind::of("future"), None);
    }
}
