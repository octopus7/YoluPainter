[한국어](ko/DEVELOPMENT.md) · [日本語](DEVELOPMENT.md)

# 開発用の手順

以下はリポジトリのルートで実行します。通常のビルドと操作は [README](../README.jp.md) を参照してください。

## テスト

```sh
cargo test --workspace --locked
```

コマンドラインと MCP サーバーは `cargo test -p yolu-cli`（`cargo clippy -p yolu-cli --all-targets -- -D warnings`）で、作りとテストの分け方は [crates/yolu-cli/README.md](../crates/yolu-cli/README.md) にあります。

GPU・画面のテストには動作する描画バックエンドが必要です。GPU テストにはアダプターがないと処理を省くものがあるため、結果の passed だけで描画確認済みとは判断せず、標準エラーの理由も確認してください。環境変数 `YOLUPAINTER_REQUIRE_GPU=1` を付けると、省かずに落とします（CI の画面のテストは付けています）。詳しくは [yolu-gpu](../crates/yolu-gpu/README.md#検証と計測) を参照してください。

レイヤーの合成の式は Rust の f32 の式が正本で、合成を通る正解は Rust で撮り直しています。正解を撮り直すときは `YOLU_GOLDEN_UPDATE=1 cargo test -p yolu-core -p yolu-io` で、違った正解だけを今の出力で書き直し、差分を見て意図した変化だけかを確かめます。Normal のチャンネルの合成とブラシの画素も f32 の式で、Rust で撮り直しています。フィルター・Generator の値など f64 のままの式は、今も 0.4.x までの Unity ブリッジ（C#）の正解と照らしています。

0.4.x までの Unity ブリッジ（C#）との照合には、リポジトリに収録された人工データを使います。正解（`crates/yolu-core/tests/golden/`・`crates/yolu-io/tests/fixtures/` など）は0.4.x までの Unity ブリッジ（C#）の出力を引き継いだ物で、C# の出力と照らし直す道は残していません。作り直すときは Rust の出力から作ります（`YOLU_GOLDEN_UPDATE=1` に対応するテストはそれで）。効果とレイヤーのロック・レイヤーの操作のつなぎ目の照合で食い違ったときは、テストを `SEAM_DUMP_DIR=<フォルダ>` で回して Rust の生のバイト列を書き出します。I/O と PSD のデータ形式・作り直し方は [I/O のフィクスチャ](../crates/yolu-io/tests/fixtures/README.md)と [PSD のフィクスチャ](../crates/yolu-io/tests/fixtures/psd/README.md)を参照してください。

### aarch64（NEON）のテストを x86_64 の Linux で回す

aarch64 の道（NEON）は、Mac の CI のほかに、x86_64 の Linux でも QEMU のユーザーモードでテストできます。Debian・Ubuntu では `qemu-user-static`・`gcc-aarch64-linux-gnu`・`libc6-dev-arm64-cross` を入れ、Rust のターゲット `aarch64-unknown-linux-gnu` を追加します（`rustup target add aarch64-unknown-linux-gnu`）。target は普段の物と分けて回します。

```sh
CARGO_TARGET_DIR=target-arm CARGO_INCREMENTAL=0 \
CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER=aarch64-linux-gnu-gcc \
CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_RUNNER="qemu-aarch64-static -L /usr/aarch64-linux-gnu" \
CC_aarch64_unknown_linux_gnu=aarch64-linux-gnu-gcc \
cargo test -p yolu-core --lib --target aarch64-unknown-linux-gnu --locked
```

QEMU は浮動小数点の演算を IEEE どおりに再現するので、NEON の結果のバイトがスカラーと一致するかを確かめられます（`YOLU_SIMD=scalar`・`YOLU_SIMD=neon` を付けて道を固定しても回せます）。速さは QEMU では測れないので、Mac の実機で測ります（下の「画素の計算の SIMD」）。型だけを見るなら、`cargo clippy -p yolu-core --all-targets --target aarch64-unknown-linux-gnu -- -D warnings` が QEMU なしで通ります。

### yolu-app の結合テストの置き方

`crates/yolu-app/tests/` のテストは、性質ごとに数本の実行ファイル（「束」）にまとめています。1 ファイルを 1 本の実行ファイルにすると、テストの数だけアプリ全体のリンクと共通部品のビルドし直しが増え、`target/` がテストの実行ファイルだけで 10 GB を超えるためです。

| 束（`cargo test -p yolu-app --test <束>`） | 中身 |
| --- | --- |
| `headless` | ウィンドウも GPU のデバイスも作らないテスト（文書・レイヤーセット・保存（バックグラウンドの保存・選択範囲・ポーズを含む）・取り込み・Live Link のフォルダの受け渡しと頼み・外からの操作（MCP の受け口）・ディスクキャッシュ・ツールの並び・ソースと画面の文（.ftl）の文言の検査）。同時に走る |
| `gui_canvas` | キャンバス・ツール・ブラシ・選択・色・効果の画面と、パネルの既定の並び（`egui_kittest`） |
| `gui_shell` | ウィンドウの全体・メニュー・設定のウィンドウとショートカットの編集・パネルの配置と別ウィンドウ・文書の出し入れ（PSD のドロップを含む）・閉じる流れと保存の途中の終了・GPU のデバイスの喪失・復旧・更新・Live Link の画面と受け取りの上限・言語・アセット・ライブラリ |
| `gui_view3d` | 3D ビュー（アンチエイリアス・ブルーム・視点の操作・複数のビュー・3D の上の選択と描画を含む）・モード（ペイント／編集／ポーズ／ハイド）・マテリアルの見た目（lilToon を含む）・ポーズ・テクスチャセット・出力 |
| `threads`・`window_lease`・`windowpos`（直下の 1 ファイル 1 本） | プロセス全体の状態を持つテスト: rayon の全体のプール・ウィンドウの貸し出しの数え・覚えたウィンドウの置き場所 |

束の中のファイルは `tests/<束>/<名前>.rs`、束の入口は `tests/<束>/main.rs` の `mod` の並びです。テストの名前は `<ファイル名>::<テスト名>` になるので、ファイルやテスト名で絞れます。

```sh
cargo test -p yolu-app --test gui_shell                      # 1 つの束
cargo test -p yolu-app --test gui_shell i18n::               # 束の中の 1 ファイル（以前の `--test i18n`）
cargo test -p yolu-app --test headless no_instruction_text:: # 以前の `--test no_instruction_text`
cargo test -p yolu-app --test gui_canvas layerops::undo      # ファイル名とテスト名の一部
cargo test -p yolu-app -- --list | grep layerops             # どの束にあるか（`Running tests/<束>/main.rs` の下）
```

- **新しいテストを追加する**: 画面を作らないなら `headless/`、作る（`common::app`・`common::gpu_thread::builder`）なら内容に近い `gui_*/` にファイルを置き、その束の `main.rs` に `mod 名前;` を 1 行追加します。追加し忘れは `headless/bundle_layout.rs` が落ちて知らせます（置いただけではビルドされず、走らないのに通るため）。ファイルの先頭で `use crate::common;` と書くと、共通部品（`tests/common/`）を `common::…` で使えます。
- 直下（`tests/<名前>.rs`）に置いた 1 ファイル 1 本のテストを束へ移すには、`git mv tests/<名前>.rs tests/<束>/<名前>.rs`、ファイル先頭の `mod common;` を `use crate::common;` に替え、束の `main.rs` に `mod <名前>;` を追加し、コメントや文書の `--test <名前>` を `--test <束> <名前>::` に直します（テストの名前は `<名前>::<元の名前>` になります）。
- **直下に 1 ファイル 1 本で置く**のは、プロセス全体の状態（rayon の全体のプール・環境変数・ウィンドウの貸し出しの数え・覚えたウィンドウの置き場所）を変える・数えるテストだけです。束の中のテストどうしは同じプロセスで走るので、そのようなテストを混ぜると順序で結果が変わります。
- **ウィンドウ（harness）は必ず `common::gpu_thread::builder()` から作る**（`Harness::builder` などを直接使うと `window_lease` が落ちます）。ウィンドウを持つテストは貸し出しで 1 つずつ走ります（lavapipe の中で同時にデバイスを作ると落ちることがあったため）。描画の設定は `common::app` か `.renderer(common::shared_gpu::renderer())`（`.wgpu()` はウィンドウごとにデバイスと 3D のパイプラインをビルドし直すので使いません。例外は、デバイスを破棄する・誤りの受け口を付けて共用のデバイスを壊す `gpu_lost` と、製品と同じデバイスの設定が要る `view3d_fx` で、自前のデバイスを貸し出しの中で作ります）。GPU の接続はプロセスで 1 つを共有し、`Renderer`・テクスチャ・3D の絵はウィンドウごとに作り直します。ウィンドウを作らなくても GPU のデバイスを作るテスト（製品のスレッドで GPU の確認・ベイクをするテスト、`common::canvas_device::begin`）は、先頭で `common::gpu_thread::lease()` を取ります（`canvas_device::begin` は中で取ります）。
- `crates/yolu-gpu/tests/` の GPU テストは、デバイス（`GpuPainter::new` など）を作る前に `support::gpu_lease::lease()` を呼びます。同じ実行ファイルの別のテストのスレッドとデバイスを同時に作って使うと、lavapipe の中でプロセスごと落ちることがあったためです（1 つのテストがデバイスを何個作っても 1 回の貸し出しで足ります）。
- **画面のテストは AppState の欄を直に触らず**、運転の口（`tests/common/drive.rs` の `Drive`。`h.doc()`・`h.act(…)` など）を通します。欄の置き場が変わっても、直すのはこのファイルだけで済みます。画面なしのテスト（`AppState`）にも付きます。
- **一時のフォルダ**は `common::tmp::test_dir(タグ)`（テストが終わると消えます）か、自分で作った所で `common::tmp::clean_up_after_test(&dir)` を呼びます。Live Link の受け渡しのフォルダは `common::livelink::Exchange::new(タグ)` が `common::tmp::test_dir` の下に作るので、置いた頼み・返事ごとテストの終わりに消えます。調べるために残したいときは `YOLUPAINTER_KEEP_TEST_FILES=1` を付けます。
- 「書き直さない」を更新時刻で確かめるときは、`common::tmp::backdate(&path)` で更新時刻を少し前にしてから比べます（時刻の粒度より早い書き直しを見逃さず、`sleep` を待たない）。
- テストが自分の実行ファイルを子として起こすとき（`--exact` にテスト名を渡す形）は、束の中では名前にモジュールの道筋（`livelink::child_unity`）が付きます。`module_path!()` から作ってください。

同じ束・同じテストを続けて回して揺れを調べるには `tools/repeat-tests.py` を使います（`--shuffle` で回ごとにテストの順を混ぜ、順序への依存も調べます）。

```sh
tools/repeat-tests.py --rounds 20 --out /tmp/repeat --test gui_canvas --test gui_shell --test gui_view3d
tools/repeat-tests.py --rounds 20 --out /tmp/repeat --shuffle --test headless
```

ビルドし直しの時間は、ほとんどが yolu-app のライブラリ 1 つの rustc です（葉の 1 ファイルを変えたあと: `cargo check` 約 6 秒、`cargo build` 約 20 秒、`cargo test -p yolu-app --test headless --no-run` 約 25 秒。リンクは 1 本 1 秒前後）。環境変数 `CARGO_INCREMENTAL=0` を付けていなければ、dev のビルドは増分で、同じ変更の後のビルドし直しは 3〜5 秒になります（キャッシュは `target/debug/incremental` に約 1.4 GB。ディスクが厳しいときだけ 0 にします）。

### yolu-core・yolu-io の結合テストの置き方

yolu-app と同じく、`crates/yolu-core/tests/`・`crates/yolu-io/tests/` のテストも性質ごとの束（`tests/<束>/main.rs`）にまとめています。テストの名前は `<ファイル名>::<テスト名>` です。

| クレート | 束（`--test <束>`） | 中身 |
| --- | --- | --- |
| yolu-core | `edit` | レイヤー・レイヤーの操作・選択範囲・コピーとペースト・履歴・チャンネル・色調補正・書き出し・2D の合成 |
| | `effects` | フィルター・Generator・Anchor・パス・スマートマテリアルと、レイヤーのロック・レイヤーの操作とのつなぎ目 |
| | `reference` | 実 C# Core の正解・収録したハッシュとの全バイトの照合 |
| | `surface` | 3D の面への投影・面のストローク・対称・メッシュのマップ・ブラシの参照元・ステンシル・チャンネルの塗り |
| | `brush`・`document`・`golden`・`mix`・`parallelism`・`paths`・`pressure`（直下の 1 ファイル 1 本） | ワーカーの閾値（`yolu_core::brush::set_parallel_dab_pixels`。プロセスで 1 つ）を変える、またはその値に頼ってダブの経路を確かめるテスト |
| | `seam_memory`（直下の 1 ファイル 1 本） | 確保を数える `#[global_allocator]` を置くので、1 本の実行ファイルにする。継ぎ目をまたぐ評価の実際の確保が見積りに収まることを確かめる |
| yolu-io | `brushes` | ブラシの取り込み（同梱の筆先・GIMP・Photoshop・CLIP STUDIO の形式・信頼できないファイル） |
| | `psd_io` | PSD の書き出し・取り込み・焼き込み・調整レイヤー・C# の正解との照合 |
| | `ylp` | .ylp の形式の読み書き・前のバージョンとの互換・断り方・C# の書き手との一致・形式の仕様の文書 |
| | `projects` | 大きな .ylp・復旧の世代・ライブラリ・アセット・配布用の写し・保存の並列・新しいプロジェクト |
| | `mesh` | メッシュのマップのベイク・レイの探索（BVH） |

```sh
cargo test -p yolu-core --test reference                 # 1 つの束
cargo test -p yolu-core --test reference seam_golden::   # 束の中の 1 ファイル（以前の `--test seam_golden`）
cargo test -p yolu-io --test ylp format_doc::            # 以前の `--test format_doc`
```

- 追加の仕方は yolu-app と同じです（内容に近い束のフォルダにファイルを置き、その `main.rs` に `mod 名前;` を追加する）。追加し忘れと、直下に理由の無い 1 ファイル 1 本が増えたことは、`yolu-core/tests/edit/bundle_layout.rs`・`yolu-io/tests/ylp/bundle_layout.rs` が落ちて知らせます。
- 共通の部品（`attach_support`・`golden_update`・`brush_files` など）は、束の `main.rs` で `#[path]` を付けて 1 度だけ宣言し、ファイルでは `use crate::<部品>;` と書きます。`include_str!`・`include_bytes!` の道はファイルの場所から数えます（束のフォルダの 1 つ上が `tests/`）。
- 使用メモリ（VmHWM）を測る手で回すテスト（`#[ignore]` の `bigdoc::measure`・`psd_stream::measure`）は、名前で絞って回します（束のほかのテストと同じプロセスで同時に走ると、測りが乱れます）。

## CI

`.github/workflows/ci.yml` は `pull_request`・`workflow_dispatch` で起動します（同じブランチの古い実行は取り消します）。`main` への push では動かしません（main は CI を通した PR からしか変わらず、push の CI は PR の最後の CI と同じ中身をもう一度ビルドするだけになるため）。代わりに `.github/workflows/main-tested.yml` が、main の中身（ファイルの木）が PR の最後の CI を通した中身と同じで、その CI が成功しているかだけを確かめます（README の CI の印はこの結果です）。違うとき（PR のブランチが main より古いまま入った）は失敗にするので、`ci.yml` を手で動かします。main 向けの PR では、テストのジョブと並べて、配る物のビルド（`dist-plan` → `dist`。`.github/workflows/dist-build.yml`）も走ります。配布はその成果物を受け取ります（[RELEASING.md](RELEASING.md#配る物をビルドする場所と受け取る道)）。外の Actions はコミットの SHA で固定し、バージョンの名前をコメントに書いています。上げるときは、そのバージョンのタグが指すコミットを確かめてから SHA を書き換えます。

- Linux のテストと静的検査（`ubuntu-24.04`）: `cargo test --workspace --exclude yolu-app --exclude yolu-gpu --exclude yolu-mock --locked --no-fail-fast`（描画しないクレート。テストは既定の並列）、配る物のツールのテスト、`cargo clippy --workspace --all-targets --locked -- -D warnings`、`cargo fmt --all -- --check`。
- Linux の画面のテスト（`ubuntu-24.04`）: Xvfb と Mesa の lavapipe（`WGPU_BACKEND=vulkan`）のソフトウェア描画で、yolu-gpu・yolu-app のテストを `tools/render-tests.py` が回します。テストの実行ファイルごとの別のプロセスを 3 列に並べ（列の中は順に）、プロセスの中は `--test-threads=1` です（ウィンドウ・GPU のデバイスを同じプロセスで同時に作ると lavapipe の中で落ちることがあったため。プロセスどうしは別のデバイス）。`YOLUPAINTER_REQUIRE_GPU=1` を付けるので、アダプターを取れないと GPU のテストは飛ばずに落ちます。回す間は全体で 20 分（`--time-limit`）で区切り、超えたテストはプロセスのグループごと殺して失敗にし、止まったテストの名前が分かるようにログの終わりをすぐに出します（その列の残りは「回さず」として落ちた物に並びます）。単体テストは `--lib`・`--bins`、ドキュメントのテストは `--doc` で回し、どれでも回らないテストの target（example・bench の `test = true`）があると、並べる前に止まります。手元で同じ形に回すときは `xvfb-run -a tools/render-tests.py --log-dir <フォルダ>`（`--lanes 1` で 1 本ずつ）。続けて、開発用のモック（`yolu-mock`。配らないクレート）のテストを `cargo test -p yolu-mock --locked -- --test-threads=1` で回します（GPU で画面を撮るので、描画しないクレートの段から外してここに置いています。上の段のビルドを使い、ウィンドウは開かないので xvfb は要りません）。runner の Ubuntu のバージョンは、収録済みの正解が glibc と Mesa のバージョンに結びつくので固定しています。
- Linux の通信の見張り（`ubuntu-24.04`。画面のテストとは別のジョブ）: 本物のアプリを `strace` の下で動かし、外への通信の試みが無いことを `tools/network-watch.py` が確かめます（[通信の見張り](#通信の見張り)の段 2）。別のジョブにしているのは、更新の確認を動かすために更新用の公開鍵（使い捨て）を組み込んで作る必要があり、その環境変数を変えると yolu-update と yolu-app を作り直すため（同じジョブに置くと、画面のテストの作った物のキャッシュが、次の回の画面のテストのビルドのやり直しになります）。キャッシュは画面のテストのジョブと共有キー（`shared-key: linux-render`）で読むだけにし（`save-if: false`）、鍵つきの物で上書きしません。xdotool が効かず場面を飛ばしたときは、終わりに `::warning::` を出します。ツールのテスト（`tools/test-network-watch.py`）は「Linux のテストと静的検査」でも回ります。
- cargo-deny（`ubuntu-24.04`。`.github/workflows/cargo-deny.yml`）: 週 1 回（月曜 03:23 UTC）と手動だけで、毎回の CI には入れません。`deny.toml` の決まりで advisories（既知の脆弱性・取り下げられたバージョン）・bans・licenses・sources を確かめます
  （手元では `cargo deny --locked check advisories bans licenses sources`）。cargo-deny はバージョンを固定して `cargo install` します（`deny.toml` の書式はバージョンに結びつくので、上げるときは一緒に確かめます）。
  `paste`（RUSTSEC-2024-0436、保守の終わり）は egui_dock がビルドの時だけ使うマクロで、脆弱性ではないので理由つきで無視しています。`yolu-mock` は配らないクレートなので、`deny.toml` の `exclude` で依存ごと調べません（配る物は `cargo xtask preflight` が見ます）。見つけた脆弱性は、更新で直せるか、使われ方に当たらないかを確かめ、後者だけを理由つきで `ignore` に足します。
- Windows（`windows-latest`、MSVC）: `cargo build -p yolu-app -p yolu-cli --locked`、core・io・brush-sets・protocol・ops・cli のテスト、app の `--lib` と、束の中の `headless_` のテスト（`--test gui_shell -- update::headless_`・`--test headless -- brush_list::headless_ recovery::headless_ livelink_files::headless_ saved_selections::headless_ pose_saved::headless_`。復旧の OS のロックと置換、Live Link の受け渡しのフォルダとファイルの置換、.ylp の置換を含む）。GPU・画面の統合テストは対象外です。
- macOS（`macos-14`、Apple Silicon）: Windows のジョブの前半と同じ手順で、`cargo build -p yolu-app -p yolu-cli --locked`、core・io・brush-sets・protocol・ops・cli のテスト、app の `--lib`。続けて、束の中の `headless_` のテストのうち `--test headless -- recovery::headless_ livelink_files::headless_`（復旧のロックと、Live Link の受け渡しのフォルダとファイルの置換）だけを回します（更新・ブラシの一覧・選択範囲・ポーズの保存の `headless_` は、このジョブでは回しません。Linux の画面のテストが Unix で回しています）。macOS のタブレットの入力（`pen::mac_tablet`）がビルドできることと、値の直し（`pen::tablet`。OS に依らないので Linux でも回る）に加えて NSEvent の定数との一致のテストが通ることを見ます。GPU・画面の統合テストは対象外です。配る物（.app と ad-hoc の署名）はこのジョブでは作らず、`dist` のジョブ（`dist-build.yml`）が macOS の runner で作ります（[配布の手順](RELEASING.md#macos-の試作)）。
- どの OS でも [Swatinem/rust-cache](https://github.com/Swatinem/rust-cache) を使い、同じブランチの古い CI は後続の実行で取り消します。

0.4.x までの Unity ブリッジ（C#）を実行する正解の再生成・照合は、その実装のソースと Unity 同梱の .NET・Mono が必要なため、この CI では回しません。収録済みの人工データを使う Rust の照合テストは通常の `cargo test` に含みます。

CI の定義は `actionlint .github/workflows/*.yml` で実行せずに検査できます。runner のバージョンを上げたときは、Ubuntu の Mesa のバージョンによる画面の正解との差を確認してください。ソフトウェア描画での結果は、Windows 実機の描画・ペンタブ・Unity 接続の確認を兼ねません。

## 画面の文字と、パネルだけの確かめ

画面の文字は、日本語と英語を `crates/yolu-app/locales/{ja,en}/<モジュール>.ftl`（Fluent）に置き、コードはキーで引きます（引数の無い文は `Lang::t`、引数のある文は `Lang::f`、core の断りの理由は `Lang::reason`）。文は実行ファイルに埋め込むので、配る物は 1 つのファイルのままです。
日英でキーの組と引数の名前が同じこと、コードが引くキーが両方にあること、どこからも引かれないキーが無いことは `cargo test -p yolu-app --test headless ftl_keys::` が見ます。数・配列・定数の選びは、今も `Lang::pick(日, 英)` を使います。

画面を作る・直すときの見た目の確かめには、開発用のクレート `yolu-mock`（配らない）を使います。本物の部品（`yolu_app::ui`）とダミーの値で、パネルや下書きを開く・PNG に撮る入口です。

```sh
cargo run -p yolu-mock -- --list                                      # 開ける物（パネル・下書き・見本帳）
cargo run -p yolu-mock -- --panel layers --png /tmp/layers.png         # 本物のパネルを 1 つだけ撮る（--lang en・--size 360x720・--scale 2・--scene empty|layers）
cargo run -p yolu-mock -- --gallery --png /tmp/gallery.png             # 今ある部品の見本帳
```

設定・キーの設定・復旧・ログのファイルは読まず、書きません。アセットのライブラリは、走らせるたびに一時のフォルダへ作る空のものです。

## 通信の見張り

アプリが外へ通信するのは、利用者が選んだ更新の確認だけです（[README](../README.jp.md)・[INSTALL](INSTALL.md) の約束）。外からの操作は、設定で入れている間だけ `127.0.0.1` で待ちます。
この約束が、新しいコードや依存で静かに破れないよう、コードと依存を読む見張り（段 1）が毎回の CI で回ります。

通信の部品の見張り（`cargo xtask netguard`。毎回の CI）と cargo-deny（週 1 回）は役が違います。netguard は「アプリが外へ通信する部品が入っていないか」を、ソースと依存のソースの字句から見ます
（ライセンスも脆弱性も見ません）。cargo-deny は「入っている依存に既知の脆弱性・許していないライセンス・知らない出どころ（registry 以外・git）が無いか」を見ます（通信するかどうかは見ません）。
どちらかが通っても、もう一方の代わりにはなりません。

### 段 1: コードと依存を読む

```sh
cargo xtask netguard         # 許す一覧の使われ方の表を出す。一覧の外の出口や依存の問題があれば終了コード 1
cargo test -p xtask netguard # 同じ確かめ（CI では `cargo test --workspace --exclude yolu-app --exclude yolu-gpu` の中で回る）と、見張りが効くことのテスト
```

実装は `crates/xtask/src/netguard/` です（`mod.rs`: 全体の流れと結果の表、`lex.rs`: 字句、`markers.rs`: 印と宛先、`allowed.rs`: 許す一覧、`deps.rs`: 依存、`uses.rs`: `use` の読み、`tests.rs`: 見張りが効くことのテスト）。

- ソース: `crates/*/src/**/*.rs` と `crates/*/build.rs`（配らない xtask は除く）から、通信と外への出口の印（`MARKERS`）を探します。ソケットの型（`TcpStream`・`TcpListener`・`UdpSocket`・`std::net`・`tokio::net`・`rustix::net` など）、
  HTTP・TLS・WebSocket の部品（`hyper`・`reqwest`・`WinHttp*`・`WinInet`・`Urlmon` など）、プロセスの起動と「開く」の呼び出し（`Command::new`・`tokio::process`・`ShellExecute*`・`xdg-open`・`open::that`・egui の `open_url`/`hyperlink`）、
  `http://`・`https://` を含む文字列です。`Command::new` は `use std::process::Command as Cmd;` の別名や `tokio::process` でも見つけ、自前の `Command` 型は印にしません。
  コメントと文字列の中の識別子には反応せず、`#[cfg(test)]` を付けた項目、`#[cfg(test)] mod x;`（`#[path = "…"]` つきなら道の指すファイル）、モジュールの中の `#![cfg(test)]` は、配る物に入らないので除きます。
  `TcpListener::bind`・`TcpStream::connect` など、型の名前に `Listener`・`Stream`・`Socket` を含む型と、その別名（`use … as L;`・`type S = …;`）の `bind`・`connect` は、宛先が 127.0.0.1 と決まる形でなければ落ちます（一覧に足しても通りません）。
  許す形は、文字列（`"127.0.0.1:0"`・`"[::1]:0"`・`"localhost:80"`）、`(host, port)` の組、`SocketAddr::from/new/V4` などの包みで、ホストは文字列か `Ipv4Addr::LOCALHOST`・`Ipv6Addr::LOOPBACK` などの定数（`IpAddr::V4(…)` の包みも可）です。
  変数・`unwrap_or`・`if`・`match`・`UNSPECIFIED`・`"0.0.0.0"` は決まらないので、宛先を呼び出しの引数に直接書きます。
- 依存: `Cargo.lock` に HTTP の客・TLS・WebSocket/QUIC・名前の引き・テレメトリ・待ち受けの枠組みの名前（`reqwest`・`ureq`・`rustls`・`quinn`・`hickory-resolver`・`sentry` など）が入ると落ちます。
  `cargo metadata`（`--locked`。取得済みの依存が足りなければ取得を許して読み直す）で、`hyper`・`hyper-util`・`socket2`・`mio` を直接の依存に持つのと、tokio の機能 `net`・`full`・`process` を使うのが yolu-mcp だけであること、
  配るアプリ（yolu-app・yolu-cli）の依存に `open`・`opener`・`webbrowser` が入らないこと（今の `open` はテスト用の依存だけ）、`socket2`・`mio`・`hyper`・`hyper-util` に依存するクレートが決めた範囲（`NET_PARTS`）から増えないこと、
  Windows の API の機能（`windows`・`windows-sys`）の通信（`Win32_Networking*`・`Win32_NetworkManagement*`・`Networking*`・`Web*`・`Win32_Web*`・`Win32_System_Com_Urlmon`・`Win32_Data_Xml_MsXml`）が、宣言でも Cargo が実際に有効にした機能
  （tokio・mio・socket2 が足す WinSock・IpHelper を含む）でも、決めた範囲（`WINDOWS_RESOLVED_NET`）から増えないことを確かめます。
  配るアプリの依存（本番とビルドスクリプトの閉包。テストだけの依存は除く）のソースも、同じ字句の読み手で読みます（今は約 440 クレート）。ソケット・名前の引き・HTTP の部品の印を使うクレートは、理由つきの一覧
  （`SOCKET_CRATES`。今は 25 名前）に載せ、載っていないクレートが使い始めたら落ちます。windows の宣言の束と、文字列・プロセスの起動の印は読みません。

落ちたときの文は、`<ファイル>:<行> の <印> が、許す一覧にありません` の形です。

許す一覧（`ALLOWED`）には、ファイルと印ごとに数（`Exactly`: 増えたら落ちる。`AtLeastOne`: 同じ種類の識別子が幾つも並ぶものだけ）と理由を書きます。数は印の出た数で、`use` の行の識別子も 1 件と数えます
（`use std::net::TcpStream;` の 1 行で `std::net` と `TcpStream` に 1 件ずつ）。足すときの決まり:

- 先に README・INSTALL の約束（更新の確認のほかに通信しない。外からの操作は設定で入れている間だけ `127.0.0.1`）を破らないか確かめます。破るなら、一覧に足さず、約束の側を決め直します。
- 理由には、何のための出口か（更新の確認・押したときだけブラウザーやファイル閲覧で開く・`127.0.0.1` の受け口・ビルドの手元など）を書きます。
- ソースの側の出口が無くなったら、その行を一覧から消します（使われない行も落ちます。`SOCKET_CRATES` は依存の更新で変わるので、使われなくなっても落ちません）。
- 足りない印は `MARKERS` に足し、`SNIPPETS`（テストの作り物のソース）にも 1 つ足します（両方の印の名前が揃わないとテストが落ちます）。

見張りが読むのはソースと依存のソース・宣言だけです。実際にどこへ接続するかは見ません（段 2 が見ます）。マクロが作るコードは追わず、機能（feature）で無効なコードも数えます。

### 段 2: 実際の通信を見る（Linux だけ）

```sh
# 更新の確認は、更新用の公開鍵を組み込んだビルドでだけ動く。使い捨ての公開鍵を渡して作る（鍵を変えると yolu-update と yolu-app を作り直す）
YOLUPAINTER_UPDATE_PUBLIC_KEY=6acc8faaa5f8beb6897bc7936ab6b930853dc4e563e4dc5f49a76f156ab16201 cargo build -p yolu-app -p yolu-cli --locked
xvfb-run -a -s "-screen 0 1920x1080x24" python3 tools/network-watch.py --log-dir /tmp/network-logs
python3 tools/test-network-watch.py   # ツール自身のテスト（アプリは起動しない）
```

`strace`・`xdotool`・`xvfb`・Mesa の lavapipe（画面のテストと同じ）が要ります。`--only main,reopen,idle,update` で起動を絞れます。

`tools/network-watch.py` は、アプリ（`yolupainter`）を `strace -f` の下で xvfb の中に起動し、CLI（`yolupainter-cli`、これも `strace` の下）で操作して、`connect`・`bind`・`listen`・`sendto`・`sendmsg`・`sendmmsg`・
`execve` を読みます。届いたか拒まれたかは見ず、試みだけで判定するので、CI から GitHub に届かなくても同じ結果になります。設定のフォルダ・書き出し先・Live Link のフォルダは、起動ごとの一時のフォルダです。

- 起動は 4 回: `main`（受け口を入れて、起動・更新の問いを Esc で「いいえ」・レイヤーと効果の編集・`xdotool` の筆・保存・PNG とテンプレートと PSD の書き出し・Live Link で 3D のモデルを開く・保存・Ctrl+Q で終了）、
  `reopen`（保存した 3D のモデル入りの文書を起動の引数で開き直す・見本）、`idle`（受け口を入れない既定の設定。更新の問いは出たまま放っておく）、`update`（更新の確認を「する」にした起動）。
  描く操作は CLI・MCP の命令にないので、筆だけは `xdotool` で動かします（`xdotool` が無い・筆が届かないときは、その場面を飛ばして表に書きます）。
- 落とす条件: PC の中（AF_UNIX の画面や D-Bus・AF_NETLINK）と 127.0.0.1・::1 のほかへの接続・送信（`sendto`・`sendmsg`・`sendmmsg` の宛先は、スレッドが多いと結果の行にだけ出るので、そこからも読む）・待ち受け。
  名前の引き（宛先のポートが 53・853・5353。127.0.0.53 のようなループバックの中継も、systemd-resolved と avahi の UNIX ソケットも。glibc が passwd などにも開く nscd のソケットは数えない）。
  受け口を入れていない起動で待ち受けること、入れた起動で 127.0.0.1 のその番号以外で待つこと、待つ呼び出しが 1 つも見えないこと。`curl` を更新の確認の場面以外で起動すること、アプリが落ちたときのダイアログ（zenity など）の起動。
- 許す通信: 更新の確認の場面（`update` の起動）で、`curl`（子のスレッドも）の外への試み。ただし curl の引数は `update/http.rs` の `curl_args`（単体テスト `curl_arguments_are_exactly_these` が全体を固定）と同じ組だけ
  （`--data`・`-H`・`-b`・`-T`・`-K`・`--url` などが足されると落ちる）、取りに行く URL は `--` の後の 1 つで、`https://github.com/YozoraKurage/YoluPainter/` の下の `?`・`#`・`@` の無い形だけです。
  curl の接続先のアドレス（GitHub の配信先の IP や名前の引き）は固定しません。ほかのプロセスの外への試みは落とします。
- 始めに、外への connect・sendto・sendmmsg、本物の名前の引き（`getaddrinfo`）、ループバックを試みる小さなプログラムを `strace` で読み、見張りが捉えることを確かめます（`strace` が使えない環境や読みの崩れで、アプリの結果が空振りにならないように）。
- 終わりに、場面ごとの接続の数と宛先の表を出します（落ちたときは、どの起動の・どの場面の・どのプロセスの・どの呼び出しかを挙げます。ログの全文は `--log-dir`）。

保証の射程: Linux の `strace` で見える試み（システムコール）だけで、通した場面だけです。Windows は段 1 だけ（ソースと依存の見張り）で、段 2 に当たるテストはありません。画面を閉じる操作は Ctrl+Q のキーで通し、
外からの操作の受け口を実行中に入れて切る操作は通していません（入れた起動と入れない起動を別々に見ています。実行中に入れて切る動きは、`crates/yolu-app/tests/headless/mcp_server.rs` のテストが 127.0.0.1 の上で確かめます）。

## Windows のインストーラーの画面なしテスト（Wine）

Windows のインストーラー（NSIS）を画面なしで通すテストは `python3 tools/test-installer.py`（Wine・MinGW-w64・`makensis` が要る。内容は [RELEASING](RELEASING.md#windows-のインストーラー)）です。

## 配布用の許諾全文

Python 3.10 以降と Cargo を使います。

```sh
python3 tools/third-party.py --bundle --offline
```

初回など依存や原文が取得済みでない場合は `--offline` を外して実行します。照合に成功すると `target/third-party/<クレート>/THIRD_PARTY_LICENSES.txt` ができるので、該当する配布物に同梱します。追加の Python パッケージは不要です。

`--target x86_64-pc-windows-msvc`・`--target x86_64-unknown-linux-gnu`・`--target aarch64-unknown-linux-gnu`（Linux の ARM。試作）・`--target universal-apple-darwin`（macOS の配布物。`aarch64-apple-darwin` と `x86_64-apple-darwin` の依存の和。この 2 つ単独も指せます）のどれかを指定すると、対象別に照合して `target/third-party/<target>/<クレート>/` へ出力します。省略時は従来の Windows GNU が対象です。`--package yolu-update` で更新クレートも確認できます。配布の詳細は [RELEASING](RELEASING.md) を参照してください。`tools/licenses-reviewed.json` に原文と SHA-256 を記録し、原文の欠落・変更や未確認のバージョン・許諾では生成を失敗させます。製品ごとの範囲とクレート以外の表記は [THIRD_PARTY.md](../THIRD_PARTY.md) にあります。

## 画素の計算の SIMD

x86_64 では、合成（Normal チャンネルを含む）・調整レイヤー・フィルターの画素の計算に AVX2（と FMA）・SSE4.1 を使い、実行時に CPU が持つ一番広い道を選ぶ
（Windows の配布物も同じ）。aarch64（Apple Silicon の Mac など）では NEON（f64 が 2 本・f32 が 4 本）を使う。NEON は aarch64 のどの CPU にもあるので、実行時の判定はしない。
それ以外の CPU は、今までの画素ごとの計算を使う。結果のバイトはどの道でも同じで、テストが道ごとに画素ごとの式と比べる。
環境変数 `YOLU_SIMD`（x86_64 は `scalar`・`sse41`・`avx2`、aarch64 は `scalar`・`neon`）で狭い道へ下げられる（CPU が持たない広い道には上げない。別の CPU の道の名前は知らない値として無視する）。
2D の合成（矩形・タイルの束・歩幅つきの粗い合成・グループの出力）はこの行の核で重ねる。参照の `composite_pixel`（画素ごとの式）とバイトが同じで、テストが全モード・マスク・クリッピング・グループ・調整レイヤー・Normal チャンネルを道ごとに比べる。
表示に寄与するレイヤー・複数のレイヤー・グループの結合も、タイルの合成で焼く（下のレイヤーへ結合する `merge_down` は、下のレイヤーの画素を下地にする方法があるので画素ごとの式のまま）。

`cargo run --release -p yolu-core --example simd_bench [blend|adjust|filter|kernel|all] [回数]` が、合成モード・調整の種類・フィルターごとの時間
（1 タイルと 4096²。`kernel` は行の核だけの ns/画素）を測る。スレッドは `SIMD_THREADS`（既定 1）、名前の絞り込みは `SIMD_FILTER`（カンマ区切り）。
Mac（Apple Silicon）の NEON の効きは、同じコマンドを `YOLU_SIMD=scalar` と既定（NEON）で回して比べる。出力の先頭の道の名前で、どの道で測ったかが分かる。
歩幅つきの粗い合成（ドラッグの間の仮の絵）は `cargo run --release -p yolu-core --example coarse_bench [回数]` で、辺 × レイヤー数 × 歩幅 × スレッド数ごとの 1 回の時間を測る
（組は `COARSE_SCENE`・`COARSE_SIZE`・`COARSE_LAYERS`・`COARSE_STRIDE`、束の枚数は `COARSE_CHUNK`）。

2D のブラシのダブの画素（丸・筆先の画像・紙の質感・デュアル・指先・ぼかし・クローン・色の混ぜ・ダブごとの色）も同じ道で、行ごとにレーンで描く。
参照は画素ごとの式（`YOLU_SIMD=scalar`）で、テストが乱数で振ったブラシ・レイヤー・タイルの大きさ・点の列を道ごとに描いて、レイヤーの全バイトとダブの数を比べる。
選択範囲・透明部分のロックは、色を塗る・消すだけのブラシなら行の核、画素ごとの色・効果のブラシでは画素ごとの式。ステンシル・乗算でない紙の質感・3D の面のダブも画素ごとの式のまま。ダブをタイルごとにワーカーで描くかは、
外接の箱の大きさに画素ごとの時間の見積もり（ブラシの種類で決まる）を掛けて決める。速いブラシの大きなダブは、ワーカーを起こす費用が勝つので直列で描く。

`cargo run --release -p yolu-core --example stroke_bench -- --threads 1` が、ブラシの種類 × 大きさ × 間隔ごとに、4096² の文書への 1 ストロークの時間を測る
（`--threads 1` は CPU 時間、2 以上は壁時計。`--features stroke-profile` を付けると段ごとの時間も出る）。ペンの入力が画面に出るまでの遅れは
`cargo run --release -p yolu-app --example stroke_latency`、取り込んだブラシは `cargo run --release -p yolu-io --example stroke_bench_imported -- --bundled 6` で測る。

3D ビューのダブは、`cargo run --release -p yolu-core --features stroke-profile --example surface_dab_bench -- --threads 8` が、合成の球（3,888 と 202,800 三角形）・文書 2048² と 4096²・ブラシの大きさ 64・128・256 ごとに、速いストロークの
ダブ 1 つの時間（中央・最大）と内訳（投影の塗り・区画の作り直し・覆いの集め・文書へ塗る）、同じ文書・大きさの 2D のダブとの比べ、1 フレームに塗る時間の枠（`--budget`、ミリ秒）で塗ったときのフレームの時間と、離した後の残りを塗り切るまでを測る。

## 機能ごとのテストと実装の置き場

使う人向けの文書から、テストのコマンド・確かめた範囲・実装の置き場をここへ集めています。

### 復旧（docs/RECOVERY.md）のテスト

```text
cargo test -p yolu-io --test projects generation::   世代の置き場（量の数え方・書く前の空きの確かめ）
cargo test -p yolu-app --lib recovery::        上限の消し方・空きの守り・設定
cargo test -p yolu-app --test headless recovery::   書き置きと上限・空きの守り・ウィンドウの数え直し
cargo test -p yolu-app --test gui_shell recovery_ui::   ウィンドウ（使う量・詳しく・使用中）
```

空きの守りは、テストでは空きを偽って確かめます。実際のディスクを満杯にしたテストはしていません。Windows の `GetDiskFreeSpaceExW` の呼び出しは、`x86_64-pc-windows-gnu` 向けにコンパイルが通ることまでで、実機では確かめていません。

### ブラシの取り込みの確かめた範囲（docs/BRUSH_IMPORT.md）

- 合成の `.sut` で確かめたこと: 設定の写し、画像（プレビュー・平らな PNG・埋め込まれた PNG）の取り出しと被覆率、複数の筆先の順、名前で決まらないときの並び、
  質感、影響元（筆圧の最小値と曲線、傾き・速さ・ランダム、読めない・大きすぎる BLOB）、旗の注記、表の欠け、`VariantID` の列の欠け、ノード・素材の数の上限、
  筆先の一部が欠けたときの知らせ、並びで当てる条件（素材と参照の数がちょうど同じ）と推定の知らせ、筆先 256 枚の打ち切り、命令の数と時間の上限
  （上限を小さくして踏むテストと、実際の上限で断られる走査の多いファイル）、SQL からの `load_extension()` の拒否、画素の予算、
  ビュー・仮想表の拒否、読まない生成列の不評価、WAL の印、約 32 万通りの壊し方（全バイトの書き換え・切り詰め・極端な値）と、壊し方では届かない
  形の正しい極端なファイル（参照が上限いっぱい・素材が上限など）。
  Windows 向け（GNU）のビルドを Wine で動かしたテストも通っています（実機の Windows では確かめていません）。
- 合成の `.sut` で確かめたこと（入り抜き・傾き・筆先の向き・手ぶれ補正。`tests/brushes/brush_import_sut.rs`）: 入り抜きの長さが画素で線の補助へ写ること・片側だけ・長さ 0・上限への丸め・
  影響先（種類・影響先の旗・BLOB の形）や単位や長さが合わないときは写さずに知らせること、傾きが大きさ・不透明度・流量の切り替えへ写ること（直線は注記なし・曲線の形は
  近似の注記・上がる曲線と太さと速さの併用は写さない・曲線の枠が無い／長さが合わないヘッダーは写さない）、筆圧の曲線を枠で選ぶこと（傾きの曲線を筆圧に取り違えない）、
  筆先の角度の巻き方・角度のランダムの旗と強さ・向きの筆圧/傾き/速さの注記、手ぶれ補正の段階の写しと範囲、整数の列が常に百分率であること（硬さの 1 は 1%）、写せた項目の並びと重ならないこと。
- 合成の `.sut` で確かめたこと（筆先・質感・影響元・補正以外の設定。`tests/brushes/brush_import_sut.rs`・`brush_import_sut_refer.rs`）: 筆先の繰り返し方法 6 通りと反転 4 通り・先端同士の比較暗・質感の回転と明るさ・コントラストの焼き込み、
  連続吹き付けとリボン（連続吹き付けと後補正が同時に立っていれば、後補正を切で写して知らせること）、影響元の全部の入力の最小値・傾きの最大値、入り抜きの影響先（写せる物の最小値と、写せない物・パーセント指定・フェードを知らせること）、
  補正（手ぶれ補正の速度による調整・後補正・はらい）、色の変化（符号つきの最小値を含む）、散布効果、デュアルブラシ（合成モード 13 種・2 つ目の筆先・質感・散布・向き・影響元）、色の混ぜの 3 方式（混色モード・輝度の補正・にじむ強さ）、
  水彩境界、はみ出し防止（色の誤差・領域拡縮）。写せない・値が範囲外の設定は、写さずに日英の文で知らせること。
- CLIP STUDIO PAINT が書き出した画像との差を数で出すテスト（`csp_line_compare.rs`・`csp_edge_compare.rs`・`csp_refer_compare.rs`・`csp_stab_compare.rs`）: 画像と `.sut` はリポジトリに入れず、環境変数 `YOLU_CSP_DIFF_DIR`（色の変化は `YOLU_CSP_COLOR_DIR`、
  差の画像を書く先は `YOLU_CSP_DIFF_OUT`）が無ければ何もせずに通ります。`cargo test -p yolu-io --test brushes csp_line_compare:: -- --ignored --nocapture` のように回すと、比べた表が出ます（取り込んだ線の式を合わせるときの、外の基準です）。
- 「CLIP STUDIO から」のウィンドウのテスト（`yolu-app/tests/headless/brush_import.rs`・`yolu-app/tests/gui_canvas/brush_import_ui.rs`・`yolu-io/tests/brushes/brush_clipstudio.rs`）: 一覧（名前・筆先の見本・読めなかった行は選べない）、選んだものだけの取り込み、
  見つからない理由（日英）、手で選んだフォルダと探し直し、探している間の取り消し、取り込み中は取り込まないこと、CLIP STUDIO のフォルダの「更新時刻・大きさ・中身・項目の数が変わらないこと」、
  入り抜き・手ぶれ補正を持つブラシの重ね方・戻し方・複製・追加・保存と読み戻し（バージョン 4）。
- 合成の C2F で確かめたこと（`tests/brushes/brush_import_sut_layer.rs`）: 原寸の筆先・質感（被覆率・向き・端の欠けたタイル・画素の無いタイル・長いオーバーフロー・UTF-8 と UTF-16LE・`Parameter`
  の終わりの語の数の違い）、元の画像と描画用の画像の優先、プレビューより C2F、塊の壊れ（印・CRC・切れ・知らない塊・塊の数）、読めない側のページ数のずれ、内部ページの輪・存在しない子、
  フォルダでないレイヤーの数、色の面・大きすぎる画像・空の面、zlib の壊れ、塊の CRC を計算し直したうえでの約 3400 通りの壊し方と切り詰め（ファイル全体は必ず取り込めること）、
  上限の内側と外側（B 木の深さ 8 の葉は読めて 9 は断る・1 行 60 MiB は読めて 64 MiB を名乗る行は断る〔小さなファイルが大きな行を名乗る形〕・行の合計が 256 MiB を超える・
  256 素材を並べても取り込み全体の仕事の上限で打ち切られる・2048×2048 の素材を並べても画素の合計の上限で打ち切られる）、同じ名前で根の違う表（同じ根の写しは読める）、
  UTF-8 と UTF-16LE の混在、タイルの塊の壊れ（番号の重複・数の不足と過剰・範囲の外・大きさの欄・長さの欄・zlib の展開の長さ・終わりの印・塊の全長）と、それぞれの断りの理由、
  素材の種類ごとの当て方（デュアルブラシ込みの数が合うとき・合わないとき・種類の分からない素材が混ざるとき）。壊れた C2F では丸い筆先に戻り、プレビューがあればそれを使う。
- 本物の `.sut` 7 つでの確かめ（テストの外。ファイルは配布の許諾が分からないのでリポジトリに入れていない。環境変数 `YOLU_REAL_SUT_DIR` のフォルダを読む `#[ignore]` のテスト
  `tests/brushes/brush_import_sut_real.rs`。ブラシの名前・ファイル名は出さず、写した値と注記の種類だけを出す）: 列のスキーマ（整数の列が百分率）、影響元の BLOB 176 件の形（ヘッダー 44 バイトと
  曲線の枠）、写した設定（傾き（大きさ）4 つ・手ぶれ補正 1 つ〔段階 6〕・筆先の角度 2 つ〔180°・220°〕・角度のランダム 3 つ〔強さ 30・80・100〕・硬さ 1% 1 つ。入り抜きは、長さを持つ物も影響先がどれもオフなので写さない）、フォルダとして一覧にして覗いても更新時刻・大きさが変わらないこと（7 個を 100 ms ほどで一覧にして覗いた）。
- 本物の `.sut` 1 つでの確かめ（テストの外。ファイルは配布の許諾が分からないのでリポジトリに入れていない。環境変数 `YOLU_REAL_SUT` のパスを読む `#[ignore]` のテスト）:
  素材 4 つの画像が原寸で読めること（筆先 2・質感 2。1 辺は 500〜1000 画素）、ブラシ 1 つの筆先と質感が（種類ごとの並びの推定で）当たり、「独自の形式で読めない」と言われないこと。
  画素の意味は、同じ環境変数の `#[ignore]` のテスト `the_pixels_are_the_black_ink_opacity_the_material_thumbnail_shows`（`src/brushes/sut/c2f.rs`）が、素材の中の CLIP STUDIO の見本の不透明度との
  相関・向き（上下・左右）・値の向き・平均・インクの色で確かめます（見本のある素材 2 つ。数値は上の「画素の意味」）。
- 確かめていないこと: **実機の Windows** で、CLIP STUDIO の入った PC のフォルダが見つかるか・CLIP STUDIO が開いているときに読めるか（上の「サブツールのフォルダから選ぶ」）。
  入り抜きの長さの単位が画素であること・影響先の列が無いバージョンの入り抜きの掛かり方・割合の意味、傾きの曲線の軸と向き、手ぶれ補正の段階の単位、筆先の角度の向きの正負と角度のランダムの強さの意味、
  向きの旗の下の 2 ビット、速さ・ランダムの影響の強さの置き場（実物 7 つはどれも既定に近い値で、ほかの値を見ていない）。
- 確かめていないこと: 本物の `.sut`（CLIP STUDIO のバージョンごと）での列の名前・単位・曲線の意味、`.sut` を CLIP STUDIO で再び読み込めること（書き出しはしません）。C2F は別のバージョン・
  色の素材（5 面）・表の根が読めない側にある素材では確かめていない（読めなければ断る）。素材の種類ごとの当て方は 1 つのファイルの 4 素材だけに基づく推定。筆先の画素の最大の
  濃さ（見た筆先では 95 / 255）が CLIP STUDIO の描画でそのまま使われるかは確かめていない。質感の「白が塗れる」向き（質感の画素を輝度 255 − v にして乗算する向き）は、
  見本が示すのは画素の意味（黒の不透明度）までで、CLIP STUDIO が質感を塗りにどう使うかは確かめていない（画面の注記は「質感の模様」の推定の知らせだけで、この向きの未確認は知らせない）。見本の無い素材（`CanvasPreview` を持つもの）の画素の意味も確かめていない。

### ツールの登録とキー（docs/SUBTOOLS.md）

ツールの名前・キー・サブツールの種類・ツールプロパティ・オプションバー・キャンバスと 3D ビューの入力は、`crates/yolu-app/src/tools/` のツールの表（`TOOLS`）が持ちます。
キーボードの割り当て・マウスと修飾キーの組み合わせ・ビューの中のキーは `crates/yolu-app/src/keymap.rs` の表が持ち、キーの処理も設定のウィンドウの「ショートカット」の区分も同じ表を読みます。
利用者が設定のウィンドウで変えた所だけは `crates/yolu-app/src/keyconfig.rs` が設定のフォルダの `keymap.json` に持ち、`keymap::install` で表に重ねます。
